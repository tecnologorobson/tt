import express from 'express';
import http from 'http';
import path from 'path';
import { WebSocketServer, WebSocket } from 'ws';
import JSZip from 'jszip';
import { createServer as createViteServer } from 'vite';
import { initialWorkspaceData } from './src/data/initialData';
import { WorkspaceData, WorkspaceFile, WorkspaceFolder, FileVersion, FileComment, ActivityEvent } from './src/types';

const app = express();
const PORT = 3000;

// Body parsers with generous limits for upload payloads
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// In-memory persistent database for cloud synchronization
let db: WorkspaceData = JSON.parse(JSON.stringify(initialWorkspaceData));

// Personal Vault database stores user accounts and private workspaces
interface PersonalAccount {
  id: string;
  name: string;
  email: string;
  avatar: string;
  password?: string;
  authProvider: 'google' | 'password';
  createdAt: string;
  bgSettings?: {
    imageUrl: string | null;
    zoom: number;
    blur: number;
    overlayOpacity: number;
  };
}

let personalUsers: PersonalAccount[] = [
  {
    id: 'usr-04testes',
    name: '04 Testes',
    email: '04testes@gmail.com',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    authProvider: 'google',
    createdAt: new Date().toISOString(),
    bgSettings: {
      imageUrl: null,
      zoom: 100,
      blur: 0,
      overlayOpacity: 10,
    },
  },
];

let personalFolders: WorkspaceFolder[] = [
  {
    id: 'pfolder-1',
    name: '01. Documentos & Contratos Pessoais',
    description: 'Documentos confidenciais protegidos no cofre pessoal',
    colorAccent: 'from-cyan-500/30 via-blue-500/20 to-indigo-500/30',
    icon: 'FileText',
    createdAt: new Date().toISOString(),
    createdBy: {
      id: 'usr-04testes',
      name: '04 Testes',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    },
    isOpen: true,
    order: 1,
    isPersonal: true,
    userId: 'usr-04testes',
  },
  {
    id: 'pfolder-2',
    name: '02. Projetos Pessoais & Códigos',
    description: 'Rascunhos de código e anotações técnicas privadas',
    colorAccent: 'from-emerald-500/30 via-teal-500/20 to-cyan-500/30',
    icon: 'Code',
    createdAt: new Date().toISOString(),
    createdBy: {
      id: 'usr-04testes',
      name: '04 Testes',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    },
    isOpen: true,
    order: 2,
    isPersonal: true,
    userId: 'usr-04testes',
  },
];

let personalFiles: WorkspaceFile[] = [
  {
    id: 'pfile-1',
    folderId: 'pfolder-1',
    name: 'Anotacoes_Pessoais_Privadas.md',
    originalName: 'Anotacoes_Pessoais_Privadas.md',
    extension: 'md',
    category: 'document',
    mimeType: 'text/markdown',
    sizeBytes: 3420,
    currentVersion: 1,
    versions: [
      {
        id: 'pver-1',
        versionNumber: 1,
        uploadedAt: new Date(Date.now() - 3600000).toISOString(),
        uploadedBy: {
          id: 'usr-04testes',
          name: '04 Testes',
          avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
          role: 'Proprietário',
        },
        sizeBytes: 3420,
        changeSummary: 'Criação inicial do cofre pessoal privado.',
        checksum: 'sha256:p98324f0c9a1e0b',
        contentSnippet: '# Meu Espaço Pessoal\nEste documento está no seu Modo Pessoal...',
      },
    ],
    createdAt: new Date(Date.now() - 3600000).toISOString(),
    updatedAt: new Date(Date.now() - 3600000).toISOString(),
    createdBy: {
      id: 'usr-04testes',
      name: '04 Testes',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      role: 'Proprietário',
    },
    isLocked: false,
    comments: [],
    tags: ['PRIVADO', 'COFRE'],
    content: `# Meu Espaço Pessoal (Modo Privado)

Bem-vindo ao seu cofre e workspace pessoal do CrystalCloud.

- ✅ **Armazenamento Privado**: Seus arquivos pessoais ficam isolados do espaço de equipe.
- ⚡ **Versionamento Automático**: Cada atualização gera uma nova revisão (v1, v2, v3).
- 🔒 **Acesso Autenticado**: Protegido por autenticação Google ou E-mail/Senha.
- 🌐 **Sincronização em Nuvem**: Seus dados são sincronizados instantaneamente.
`,
    isPersonal: true,
    userId: 'usr-04testes',
  },
  {
    id: 'pfile-2',
    folderId: 'pfolder-2',
    name: 'config.secrets.json',
    originalName: 'config.secrets.json',
    extension: 'json',
    category: 'code',
    mimeType: 'application/json',
    sizeBytes: 1150,
    currentVersion: 1,
    versions: [
      {
        id: 'pver-2',
        versionNumber: 1,
        uploadedAt: new Date(Date.now() - 7200000).toISOString(),
        uploadedBy: {
          id: 'usr-04testes',
          name: '04 Testes',
          avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
          role: 'Proprietário',
        },
        sizeBytes: 1150,
        changeSummary: 'Configurações pessoais criptografadas.',
        checksum: 'sha256:c987fa012e87c',
      },
    ],
    createdAt: new Date(Date.now() - 7200000).toISOString(),
    updatedAt: new Date(Date.now() - 7200000).toISOString(),
    createdBy: {
      id: 'usr-04testes',
      name: '04 Testes',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      role: 'Proprietário',
    },
    isLocked: false,
    comments: [],
    tags: ['SECRETS', 'JSON'],
    content: `{\n  "environment": "personal-vault",\n  "encryption": "AES-GCM-256",\n  "syncEnabled": true,\n  "owner": "04testes@gmail.com"\n}`,
    isPersonal: true,
    userId: 'usr-04testes',
  },
];

// Create HTTP server
const server = http.createServer(app);

// WebSocket Server attached to same port
const wss = new WebSocketServer({ server, path: '/ws' });
const clients = new Set<WebSocket>();

function broadcast(type: string, payload: any) {
  const message = JSON.stringify({ type, payload, timestamp: new Date().toISOString() });
  for (const client of clients) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  }
}

wss.on('connection', (ws) => {
  clients.add(ws);
  db.syncState.connectedClients = clients.size;
  db.syncState.lastSyncedAt = new Date().toISOString();

  // Send initial state upon connection
  ws.send(JSON.stringify({
    type: 'SYNC_INIT',
    payload: db,
    timestamp: new Date().toISOString(),
  }));

  // Broadcast presence update
  broadcast('PRESENCE_UPDATE', {
    connectedClients: clients.size,
    lastSyncedAt: db.syncState.lastSyncedAt,
  });

  ws.on('message', (data) => {
    try {
      const parsed = JSON.parse(data.toString());
      if (parsed.type === 'PING') {
        ws.send(JSON.stringify({ type: 'PONG', clientTime: parsed.clientTime, serverTime: Date.now() }));
      } else if (parsed.type === 'MEMBER_PRESENCE') {
        // Update member active folder or status
        const member = db.members.find(m => m.id === parsed.memberId);
        if (member) {
          if (parsed.activeFolderId) member.activeFolderId = parsed.activeFolderId;
          if (parsed.status) member.status = parsed.status;
          broadcast('MEMBER_UPDATED', member);
        }
      }
    } catch {
      // ignore parse errors
    }
  });

  ws.on('close', () => {
    clients.delete(ws);
    db.syncState.connectedClients = Math.max(1, clients.size);
    broadcast('PRESENCE_UPDATE', {
      connectedClients: clients.size,
      lastSyncedAt: new Date().toISOString(),
    });
  });
});

// ==================== REST API ENDPOINTS ====================

// 1. Health check & Sync state
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    syncedAt: db.syncState.lastSyncedAt,
    connectedClients: clients.size,
    region: db.syncState.serverRegion,
    totalFiles: db.files.length,
    totalFolders: db.folders.length,
  });
});

// 2. Fetch full workspace data
app.get('/api/workspace', (req, res) => {
  db.syncState.lastSyncedAt = new Date().toISOString();
  res.json(db);
});

// 2.1 Update Team Appearance & Workspace Settings (synced to all team members)
app.post('/api/workspace/settings', (req, res) => {
  const { bgSettings } = req.body;
  if (bgSettings !== undefined) {
    db.bgSettings = bgSettings;
  }
  db.syncState.lastSyncedAt = new Date().toISOString();

  const act: ActivityEvent = {
    id: `act-${Date.now()}`,
    type: 'sync',
    userId: 'user-current',
    userName: 'Você',
    userAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    targetId: 'workspace-settings',
    targetName: 'Aparência & Configurações da Equipe',
    details: 'Atualizou o plano de fundo e configurações visuais compartilhadas da equipe.',
    timestamp: new Date().toISOString(),
  };
  db.activities.unshift(act);

  // Broadcast to all team clients in real-time
  broadcast('TEAM_SETTINGS_UPDATED', {
    bgSettings: db.bgSettings,
    syncState: db.syncState,
    activity: act,
  });

  res.json({ success: true, bgSettings: db.bgSettings, syncState: db.syncState });
});

// 3. Create or update folder
app.post('/api/folders', (req, res) => {
  const { name, description, colorAccent, icon } = req.body;
  if (!name) {
    return res.status(400).json({ error: 'Nome da pasta é obrigatório.' });
  }

  const newFolder: WorkspaceFolder = {
    id: `folder-${Date.now()}`,
    name,
    description: description || '',
    colorAccent: colorAccent || 'from-cyan-500/30 via-blue-500/20 to-indigo-500/30',
    icon: icon || 'Folder',
    createdAt: new Date().toISOString(),
    createdBy: {
      id: 'user-current',
      name: 'Você (Colaborador Ativo)',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    },
    isOpen: true,
    order: db.folders.length + 1,
  };

  db.folders.push(newFolder);

  const act: ActivityEvent = {
    id: `act-${Date.now()}`,
    type: 'folder_create',
    userId: 'user-current',
    userName: 'Você',
    userAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    targetId: newFolder.id,
    targetName: newFolder.name,
    details: `Criou a pasta cristalizada "${newFolder.name}".`,
    timestamp: new Date().toISOString(),
  };
  db.activities.unshift(act);

  broadcast('FOLDER_CREATED', { folder: newFolder, activity: act });
  res.json({ success: true, folder: newFolder });
});

// 4. Delete folder
app.delete('/api/folders/:id', (req, res) => {
  const { id } = req.params;
  const folderIndex = db.folders.findIndex(f => f.id === id);
  if (folderIndex === -1) {
    return res.status(404).json({ error: 'Pasta não encontrada.' });
  }

  const folderName = db.folders[folderIndex].name;
  db.folders.splice(folderIndex, 1);
  // Also remove files belonging to this folder
  db.files = db.files.filter(f => f.folderId !== id);

  const act: ActivityEvent = {
    id: `act-${Date.now()}`,
    type: 'delete',
    userId: 'user-current',
    userName: 'Você',
    userAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    targetId: id,
    targetName: folderName,
    details: `Excluiu a pasta "${folderName}" e seus arquivos.`,
    timestamp: new Date().toISOString(),
  };
  db.activities.unshift(act);

  broadcast('FOLDER_DELETED', { folderId: id, activity: act });
  res.json({ success: true });
});

// Helper to determine file category
function determineCategory(ext: string, mime: string): WorkspaceFile['category'] {
  const lowerExt = ext.toLowerCase();
  if (['png', 'jpg', 'jpeg', 'svg', 'webp', 'gif', 'bmp', 'ico'].includes(lowerExt) || mime.startsWith('image/')) {
    return 'image';
  }
  if (['pdf', 'doc', 'docx', 'txt', 'rtf', 'odt', 'epub'].includes(lowerExt) || mime.includes('document') || mime.includes('pdf')) {
    return 'document';
  }
  if (['js', 'ts', 'tsx', 'jsx', 'json', 'html', 'css', 'py', 'java', 'c', 'cpp', 'rs', 'go', 'sh', 'sql', 'md'].includes(lowerExt)) {
    return 'code';
  }
  if (['mp3', 'wav', 'ogg', 'm4a', 'flac', 'aac'].includes(lowerExt) || mime.startsWith('audio/')) {
    return 'audio';
  }
  if (['mp4', 'webm', 'mov', 'avi', 'mkv'].includes(lowerExt) || mime.startsWith('video/')) {
    return 'video';
  }
  if (['zip', 'rar', 'tar', 'gz', '7z'].includes(lowerExt) || mime.includes('zip') || mime.includes('compressed')) {
    return 'archive';
  }
  return 'other';
}

// 5. Upload File (handles single, multi, and AUTOMATIC VERSIONING if file name already exists in the same folder)
app.post('/api/upload', (req, res) => {
  const { folderId, name, sizeBytes, mimeType, content, previewUrl, changeSummary, author } = req.body;

  if (!folderId || !name) {
    return res.status(400).json({ error: 'Folder ID e nome do arquivo são obrigatórios.' });
  }

  const existingFile = db.files.find(f => f.folderId === folderId && f.name.toLowerCase() === name.toLowerCase());
  const ext = name.includes('.') ? name.split('.').pop() || 'bin' : 'bin';
  const category = determineCategory(ext, mimeType || '');
  const uploader = author || {
    id: 'user-current',
    name: 'Você (Colaborador Ativo)',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    role: 'Administrador',
  };

  const checksum = `sha256:${Math.random().toString(36).substring(2)}${Date.now().toString(36)}`;

  if (existingFile) {
    // AUTOMATIC VERSIONING: File exists, increment version!
    const nextVerNum = existingFile.currentVersion + 1;
    const newVersion: FileVersion = {
      id: `ver-${existingFile.id}-${nextVerNum}`,
      versionNumber: nextVerNum,
      uploadedAt: new Date().toISOString(),
      uploadedBy: uploader,
      sizeBytes: Number(sizeBytes) || existingFile.sizeBytes,
      changeSummary: changeSummary || `Upload automático de nova revisão (v${nextVerNum}).`,
      checksum,
      contentSnippet: content ? content.slice(0, 200) : undefined,
      previewUrl: previewUrl || existingFile.previewUrl,
    };

    existingFile.currentVersion = nextVerNum;
    existingFile.updatedAt = new Date().toISOString();
    existingFile.sizeBytes = Number(sizeBytes) || existingFile.sizeBytes;
    existingFile.versions.push(newVersion);
    if (content !== undefined) existingFile.content = content;
    if (previewUrl !== undefined) existingFile.previewUrl = previewUrl;

    const act: ActivityEvent = {
      id: `act-${Date.now()}`,
      type: 'upload',
      userId: uploader.id,
      userName: uploader.name,
      userAvatar: uploader.avatar,
      targetId: existingFile.id,
      targetName: existingFile.name,
      details: `Versionou automaticamente "${existingFile.name}" para v${nextVerNum}.`,
      timestamp: new Date().toISOString(),
    };
    db.activities.unshift(act);

    // Update total storage used
    db.syncState.cloudStorageUsedBytes += Number(sizeBytes) || 1024;

    broadcast('FILE_VERSIONED', { file: existingFile, version: newVersion, activity: act });
    return res.json({ success: true, file: existingFile, isNewVersion: true, versionNumber: nextVerNum });
  } else {
    // NEW FILE
    const fileId = `file-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const initialVer: FileVersion = {
      id: `ver-${fileId}-1`,
      versionNumber: 1,
      uploadedAt: new Date().toISOString(),
      uploadedBy: uploader,
      sizeBytes: Number(sizeBytes) || 1024,
      changeSummary: changeSummary || 'Upload inicial do arquivo.',
      checksum,
      contentSnippet: content ? content.slice(0, 200) : undefined,
      previewUrl: previewUrl,
    };

    const newFile: WorkspaceFile = {
      id: fileId,
      folderId,
      name,
      originalName: name,
      extension: ext,
      category,
      mimeType: mimeType || 'application/octet-stream',
      sizeBytes: Number(sizeBytes) || 1024,
      currentVersion: 1,
      versions: [initialVer],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      createdBy: uploader,
      isLocked: false,
      comments: [],
      tags: [category.toUpperCase(), ext.toUpperCase()],
      content: content || '',
      previewUrl: previewUrl || '',
    };

    db.files.push(newFile);

    const act: ActivityEvent = {
      id: `act-${Date.now()}`,
      type: 'upload',
      userId: uploader.id,
      userName: uploader.name,
      userAvatar: uploader.avatar,
      targetId: newFile.id,
      targetName: newFile.name,
      details: `Fez upload de "${newFile.name}" (v1).`,
      timestamp: new Date().toISOString(),
    };
    db.activities.unshift(act);

    db.syncState.cloudStorageUsedBytes += Number(sizeBytes) || 1024;

    broadcast('FILE_CREATED', { file: newFile, activity: act });
    return res.json({ success: true, file: newFile, isNewVersion: false, versionNumber: 1 });
  }
});

// 6. Revert File to a previous version
app.post('/api/files/:id/revert', (req, res) => {
  const { id } = req.params;
  const { versionNumber } = req.body;

  const file = db.files.find(f => f.id === id);
  if (!file) return res.status(404).json({ error: 'Arquivo não encontrado.' });

  const targetVersion = file.versions.find(v => v.versionNumber === Number(versionNumber));
  if (!targetVersion) return res.status(404).json({ error: 'Versão não encontrada.' });

  // Create a new version as the reversion point to maintain immutable audit trail
  const newVerNum = file.currentVersion + 1;
  const revertVersion: FileVersion = {
    id: `ver-${file.id}-${newVerNum}`,
    versionNumber: newVerNum,
    uploadedAt: new Date().toISOString(),
    uploadedBy: {
      id: 'user-current',
      name: 'Você (Colaborador Ativo)',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      role: 'Administrador',
    },
    sizeBytes: targetVersion.sizeBytes,
    changeSummary: `Reversão automática para o estado da v${versionNumber}.`,
    checksum: targetVersion.checksum,
    contentSnippet: targetVersion.contentSnippet,
    previewUrl: targetVersion.previewUrl || file.previewUrl,
  };

  file.currentVersion = newVerNum;
  file.updatedAt = new Date().toISOString();
  file.sizeBytes = targetVersion.sizeBytes;
  if (targetVersion.previewUrl) file.previewUrl = targetVersion.previewUrl;
  file.versions.push(revertVersion);

  const act: ActivityEvent = {
    id: `act-${Date.now()}`,
    type: 'version_revert',
    userId: 'user-current',
    userName: 'Você',
    userAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    targetId: file.id,
    targetName: file.name,
    details: `Reverteu "${file.name}" para a versão v${versionNumber} (registrado como v${newVerNum}).`,
    timestamp: new Date().toISOString(),
  };
  db.activities.unshift(act);

  broadcast('FILE_REVERTED', { file, revertedTo: versionNumber, newVersion: revertVersion, activity: act });
  res.json({ success: true, file, currentVersion: newVerNum });
});

// 7. Toggle Lock / Checkout
app.post('/api/files/:id/lock', (req, res) => {
  const { id } = req.params;
  const file = db.files.find(f => f.id === id);
  if (!file) return res.status(404).json({ error: 'Arquivo não encontrado.' });

  file.isLocked = !file.isLocked;
  file.lockedBy = file.isLocked
    ? {
        id: 'user-current',
        name: 'Você (Colaborador Ativo)',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      }
    : null;

  const act: ActivityEvent = {
    id: `act-${Date.now()}`,
    type: file.isLocked ? 'lock' : 'unlock',
    userId: 'user-current',
    userName: 'Você',
    userAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    targetId: file.id,
    targetName: file.name,
    details: file.isLocked ? `Bloqueou "${file.name}" para edição exclusiva.` : `Liberou o bloqueio de "${file.name}".`,
    timestamp: new Date().toISOString(),
  };
  db.activities.unshift(act);

  broadcast('FILE_LOCK_TOGGLED', { file, activity: act });
  res.json({ success: true, isLocked: file.isLocked, lockedBy: file.lockedBy });
});

// 8. Add collaborative comment
app.post('/api/files/:id/comments', (req, res) => {
  const { id } = req.params;
  const { content, author } = req.body;
  if (!content) return res.status(400).json({ error: 'Conteúdo do comentário é obrigatório.' });

  const file = db.files.find(f => f.id === id);
  if (!file) return res.status(404).json({ error: 'Arquivo não encontrado.' });

  const newComment: FileComment = {
    id: `comm-${Date.now()}`,
    fileId: id,
    author: author || {
      id: 'user-current',
      name: 'Você (Colaborador Ativo)',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      role: 'Administrador',
    },
    content,
    createdAt: new Date().toISOString(),
  };

  file.comments.push(newComment);

  const act: ActivityEvent = {
    id: `act-${Date.now()}`,
    type: 'comment',
    userId: newComment.author.id,
    userName: newComment.author.name,
    userAvatar: newComment.author.avatar,
    targetId: file.id,
    targetName: file.name,
    details: `Comentou em "${file.name}": "${content.slice(0, 45)}..."`,
    timestamp: new Date().toISOString(),
  };
  db.activities.unshift(act);

  broadcast('COMMENT_ADDED', { fileId: id, comment: newComment, activity: act });
  res.json({ success: true, comment: newComment });
});

// 9. Delete file
app.delete('/api/files/:id', (req, res) => {
  const { id } = req.params;
  const fileIndex = db.files.findIndex(f => f.id === id);
  if (fileIndex === -1) return res.status(404).json({ error: 'Arquivo não encontrado.' });

  const file = db.files[fileIndex];
  db.files.splice(fileIndex, 1);

  const act: ActivityEvent = {
    id: `act-${Date.now()}`,
    type: 'delete',
    userId: 'user-current',
    userName: 'Você',
    userAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    targetId: id,
    targetName: file.name,
    details: `Excluiu o arquivo "${file.name}".`,
    timestamp: new Date().toISOString(),
  };
  db.activities.unshift(act);

  broadcast('FILE_DELETED', { fileId: id, activity: act });
  res.json({ success: true });
});

// 10. Download single file (with optional ?version=X) - Handles binary and text data
app.get('/api/download/:fileId', (req, res) => {
  const { fileId } = req.params;
  const { version } = req.query;

  const file = db.files.find(f => f.id === fileId) || personalFiles.find(f => f.id === fileId);
  if (!file) return res.status(404).send('Arquivo não encontrado.');

  const ver = version ? file.versions?.find(v => v.versionNumber === Number(version)) : file.versions?.[file.versions.length - 1];
  const rawContent = file.content || ver?.contentSnippet;

  res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(file.name)}"`);

  // Handle Base64 Data URL (images, binaries, documents, etc.)
  if (rawContent && typeof rawContent === 'string' && rawContent.startsWith('data:')) {
    try {
      const parts = rawContent.split(',');
      const mimeMatch = parts[0].match(/:(.*?);/);
      const mime = mimeMatch ? mimeMatch[1] : (file.mimeType || 'application/octet-stream');
      const isBase64 = parts[0].includes('base64');
      
      const buffer = isBase64
        ? Buffer.from(parts[1] || '', 'base64')
        : Buffer.from(decodeURIComponent(parts[1] || ''), 'utf-8');

      res.setHeader('Content-Type', mime);
      res.setHeader('Content-Length', buffer.length);
      return res.end(buffer);
    } catch (err) {
      console.error('Error decoding file buffer:', err);
    }
  }

  // Handle text or fallback
  const filePayload = rawContent || `Contéudo do arquivo ${file.name} (Versão ${ver ? ver.versionNumber : file.currentVersion})\nChecksum: ${ver ? (ver.checksum || ver.hashChecksum) : 'N/A'}\nData: ${file.updatedAt}`;
  res.setHeader('Content-Type', file.mimeType || 'text/plain; charset=utf-8');
  res.send(filePayload);
});

// 11. Download entire folder as ZIP (with uncorrupted binary file packing)
app.get('/api/download-folder/:folderId', async (req, res) => {
  try {
    const { folderId } = req.params;
    const folder = db.folders.find(f => f.id === folderId) || personalFolders.find(f => f.id === folderId);
    if (!folder) return res.status(404).send('Pasta não encontrada.');

    const folderFiles = [...db.files, ...personalFiles].filter(f => f.folderId === folderId);
    const zip = new JSZip();

    // Add manifest
    const manifest = {
      folderName: folder.name,
      description: folder.description,
      exportedAt: new Date().toISOString(),
      totalFiles: folderFiles.length,
      files: folderFiles.map(f => ({
        name: f.name,
        currentVersion: f.currentVersion,
        totalVersions: f.versions?.length || 1,
        sizeBytes: f.sizeBytes,
      })),
    };
    zip.file('_MANIFEST_WORKSPACE.json', JSON.stringify(manifest, null, 2));

    // Add all files
    for (const f of folderFiles) {
      if (f.content && typeof f.content === 'string' && f.content.startsWith('data:')) {
        try {
          const parts = f.content.split(',');
          const isBase64 = parts[0].includes('base64');
          const buffer = isBase64
            ? Buffer.from(parts[1] || '', 'base64')
            : Buffer.from(decodeURIComponent(parts[1] || ''), 'utf-8');
          zip.file(f.name, buffer);
        } catch {
          zip.file(f.name, f.content);
        }
      } else {
        const content = f.content || `Arquivo: ${f.name}\nVersão: v${f.currentVersion}\nÚltima Modificação: ${f.updatedAt}`;
        zip.file(f.name, content);
      }
    }

    const zipBuffer = await zip.generateAsync({ type: 'nodebuffer' });
    const cleanFolderName = folder.name.replace(/[^a-zA-Z0-9_\-]/g, '_');

    res.setHeader('Content-Disposition', `attachment; filename="${cleanFolderName}_CrystalCloud.zip"`);
    res.setHeader('Content-Type', 'application/zip');
    res.send(zipBuffer);
  } catch (err) {
    console.error('Erro ao gerar ZIP da pasta:', err);
    res.status(500).send('Erro ao comprimir pasta em ZIP.');
  }
});

// ==================== PERSONAL VAULT REST API ====================

// Auth: Google Sign-In
app.post('/api/auth/google', (req, res) => {
  const { email, name, avatar } = req.body;
  if (!email) {
    return res.status(400).json({ error: 'Email do Google é obrigatório.' });
  }

  const cleanEmail = email.toLowerCase().trim();
  let user = personalUsers.find(u => u.email.toLowerCase() === cleanEmail);
  if (!user) {
    const newUserId = `usr-${Date.now()}`;
    user = {
      id: newUserId,
      name: name || cleanEmail.split('@')[0],
      email: cleanEmail,
      avatar: avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      authProvider: 'google',
      createdAt: new Date().toISOString(),
      bgSettings: {
        imageUrl: null,
        zoom: 100,
        blur: 0,
        overlayOpacity: 10,
      },
    };
    personalUsers.push(user);

    // Seed default private folders
    const defaultFolder: WorkspaceFolder = {
      id: `pfolder-${Date.now()}`,
      name: 'Meu Cofre Pessoal',
      description: 'Arquivos privados sincronizados e protegidos',
      colorAccent: 'from-cyan-500/30 via-blue-500/20 to-indigo-500/30',
      icon: 'FileText',
      createdAt: new Date().toISOString(),
      createdBy: {
        id: user.id,
        name: user.name,
        avatar: user.avatar,
      },
      isOpen: true,
      order: 1,
      isPersonal: true,
      userId: user.id,
    };
    personalFolders.push(defaultFolder);
  } else {
    if (name) user.name = name;
    if (avatar) user.avatar = avatar;
    if (!user.bgSettings) {
      user.bgSettings = {
        imageUrl: null,
        zoom: 100,
        blur: 0,
        overlayOpacity: 10,
      };
    }
  }

  res.json({ success: true, user });
});

// Auth: Email & Password Login
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email e senha são obrigatórios.' });
  }

  const cleanEmail = email.toLowerCase().trim();
  let user = personalUsers.find(u => u.email.toLowerCase() === cleanEmail);
  if (!user) {
    // Auto-create account for seamless device onboarding
    const newUserId = `usr-${Date.now()}`;
    user = {
      id: newUserId,
      name: cleanEmail.split('@')[0],
      email: cleanEmail,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      authProvider: 'password',
      password,
      createdAt: new Date().toISOString(),
      bgSettings: {
        imageUrl: null,
        zoom: 100,
        blur: 0,
        overlayOpacity: 10,
      },
    };
    personalUsers.push(user);

    const defaultFolder: WorkspaceFolder = {
      id: `pfolder-${Date.now()}`,
      name: 'Documentos Pessoais',
      description: 'Seus arquivos privados e protegidos',
      colorAccent: 'from-cyan-500/30 via-blue-500/20 to-indigo-500/30',
      icon: 'FileText',
      createdAt: new Date().toISOString(),
      createdBy: {
        id: user.id,
        name: user.name,
        avatar: user.avatar,
      },
      isOpen: true,
      order: 1,
      isPersonal: true,
      userId: user.id,
    };
    personalFolders.push(defaultFolder);
  } else {
    if (!user.bgSettings) {
      user.bgSettings = {
        imageUrl: null,
        zoom: 100,
        blur: 0,
        overlayOpacity: 10,
      };
    }
  }

  res.json({ success: true, user });
});

// Auth: Email & Password Registration
app.post('/api/auth/register', (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Nome, e-mail e senha são obrigatórios.' });
  }

  const cleanEmail = email.toLowerCase().trim();
  let existing = personalUsers.find(u => u.email.toLowerCase() === cleanEmail);
  if (existing) {
    return res.status(400).json({ error: 'Já existe uma conta com este e-mail.' });
  }

  const user: PersonalAccount = {
    id: `usr-${Date.now()}`,
    name,
    email: cleanEmail,
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    authProvider: 'password',
    password,
    createdAt: new Date().toISOString(),
    bgSettings: {
      imageUrl: null,
      zoom: 100,
      blur: 0,
      overlayOpacity: 10,
    },
  };
  personalUsers.push(user);

  const defaultFolder: WorkspaceFolder = {
    id: `pfolder-${Date.now()}`,
    name: 'Documentos & Projetos Pessoais',
    description: 'Armazenamento privado exclusivo',
    colorAccent: 'from-cyan-500/30 via-blue-500/20 to-indigo-500/30',
    icon: 'FileText',
    createdAt: new Date().toISOString(),
    createdBy: {
      id: user.id,
      name: user.name,
      avatar: user.avatar,
    },
    isOpen: true,
    order: 1,
    isPersonal: true,
    userId: user.id,
  };
  personalFolders.push(defaultFolder);

  res.json({ success: true, user });
});

// Fetch Personal Workspace (by userId or email)
app.get('/api/personal/workspace', (req, res) => {
  const { userId, email } = req.query;
  const cleanEmail = typeof email === 'string' ? email.toLowerCase().trim() : undefined;
  
  let user: PersonalAccount | undefined;
  if (cleanEmail) {
    user = personalUsers.find(u => u.email.toLowerCase() === cleanEmail);
  }
  if (!user && userId) {
    user = personalUsers.find(u => u.id === userId);
  }
  if (!user) {
    user = personalUsers.find(u => u.id === 'usr-04testes');
  }

  const targetUserId = user?.id || (userId as string) || 'usr-04testes';
  const userFolders = personalFolders.filter(f => !f.userId || f.userId === targetUserId);
  const userFiles = personalFiles.filter(f => !f.userId || f.userId === targetUserId);
  const storageUsed = userFiles.reduce((sum, f) => sum + f.sizeBytes, 0);

  res.json({
    folders: userFolders,
    files: userFiles,
    cloudStorageUsedBytes: storageUsed,
    cloudStorageLimitBytes: 15 * 1024 * 1024 * 1024, // 15 GB
    user: user ? {
      id: user.id,
      name: user.name,
      email: user.email,
      avatar: user.avatar,
      authProvider: user.authProvider,
      createdAt: user.createdAt,
      bgSettings: user.bgSettings,
    } : undefined,
    bgSettings: user?.bgSettings || {
      imageUrl: null,
      zoom: 100,
      blur: 0,
      overlayOpacity: 10,
    },
  });
});

// Fetch Personal Settings (by userId or email)
app.get('/api/personal/settings', (req, res) => {
  const { userId, email } = req.query;
  const cleanEmail = typeof email === 'string' ? email.toLowerCase().trim() : undefined;
  
  let user: PersonalAccount | undefined;
  if (cleanEmail) {
    user = personalUsers.find(u => u.email.toLowerCase() === cleanEmail);
  }
  if (!user && userId) {
    user = personalUsers.find(u => u.id === userId);
  }
  if (!user) {
    user = personalUsers.find(u => u.id === 'usr-04testes');
  }

  const bgSettings = user?.bgSettings || {
    imageUrl: null,
    zoom: 100,
    blur: 0,
    overlayOpacity: 10,
  };
  res.json({ success: true, bgSettings });
});

// Update Personal Settings (Tied directly to the user's email/account across all devices)
app.post('/api/personal/settings', (req, res) => {
  const { userId, email, bgSettings } = req.body;
  const cleanEmail = typeof email === 'string' ? email.toLowerCase().trim() : undefined;

  let user: PersonalAccount | undefined;
  if (cleanEmail) {
    user = personalUsers.find(u => u.email.toLowerCase() === cleanEmail);
  }
  if (!user && userId) {
    user = personalUsers.find(u => u.id === userId);
  }
  if (!user) {
    user = personalUsers.find(u => u.id === 'usr-04testes');
  }

  if (user && bgSettings) {
    user.bgSettings = bgSettings;
    
    // Broadcast personal update so any other active devices/tabs with this email sync instantly
    broadcast('PERSONAL_SETTINGS_UPDATED', {
      userId: user.id,
      email: user.email.toLowerCase(),
      bgSettings: user.bgSettings,
    });
  }

  res.json({ success: true, bgSettings: user?.bgSettings || bgSettings });
});

// Create Personal Folder
app.post('/api/personal/folders', (req, res) => {
  const { userId, name, description, colorAccent, icon } = req.body;
  if (!name) return res.status(400).json({ error: 'Nome da pasta é obrigatório.' });

  const targetUserId = userId || 'usr-04testes';
  const user = personalUsers.find(u => u.id === targetUserId) || {
    id: targetUserId,
    name: 'Usuário Pessoal',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
  };

  const newFolder: WorkspaceFolder = {
    id: `pfolder-${Date.now()}`,
    name,
    description: description || '',
    colorAccent: colorAccent || 'from-cyan-500/30 via-blue-500/20 to-indigo-500/30',
    icon: icon || 'Folder',
    createdAt: new Date().toISOString(),
    createdBy: {
      id: user.id,
      name: user.name,
      avatar: user.avatar,
    },
    isOpen: true,
    order: personalFolders.length + 1,
    isPersonal: true,
    userId: targetUserId,
  };

  personalFolders.push(newFolder);
  res.json({ success: true, folder: newFolder });
});

// Delete Personal Folder
app.delete('/api/personal/folders/:id', (req, res) => {
  const { id } = req.params;
  const idx = personalFolders.findIndex(f => f.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Pasta pessoal não encontrada.' });

  personalFolders.splice(idx, 1);
  personalFiles = personalFiles.filter(f => f.folderId !== id);
  res.json({ success: true });
});

// Upload Personal File with Automatic Versioning
app.post('/api/personal/upload', (req, res) => {
  const { userId, folderId, name, sizeBytes, mimeType, content, previewUrl, changeSummary } = req.body;
  if (!folderId || !name) return res.status(400).json({ error: 'Pasta e nome são obrigatórios.' });

  const targetUserId = userId || 'usr-04testes';
  const user = personalUsers.find(u => u.id === targetUserId) || {
    id: targetUserId,
    name: 'Usuário Pessoal',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
  };

  const existingFile = personalFiles.find(f => f.folderId === folderId && f.name.toLowerCase() === name.toLowerCase());
  const ext = name.includes('.') ? name.split('.').pop() || 'bin' : 'bin';
  const category = determineCategory(ext, mimeType || '');
  const checksum = `sha256:${Math.random().toString(36).substring(2)}${Date.now().toString(36)}`;

  if (existingFile) {
    const nextVerNum = existingFile.currentVersion + 1;
    const newVersion: FileVersion = {
      id: `pver-${existingFile.id}-${nextVerNum}`,
      versionNumber: nextVerNum,
      uploadedAt: new Date().toISOString(),
      uploadedBy: {
        id: user.id,
        name: user.name,
        avatar: user.avatar,
        role: 'Proprietário',
      },
      sizeBytes: Number(sizeBytes) || existingFile.sizeBytes,
      changeSummary: changeSummary || `Upload automático de nova revisão privada (v${nextVerNum}).`,
      checksum,
      contentSnippet: content ? content.slice(0, 200) : undefined,
      previewUrl: previewUrl || existingFile.previewUrl,
    };

    existingFile.currentVersion = nextVerNum;
    existingFile.updatedAt = new Date().toISOString();
    existingFile.sizeBytes = Number(sizeBytes) || existingFile.sizeBytes;
    existingFile.versions.push(newVersion);
    if (content !== undefined) existingFile.content = content;
    if (previewUrl !== undefined) existingFile.previewUrl = previewUrl;

    return res.json({ success: true, file: existingFile, isNewVersion: true, versionNumber: nextVerNum });
  } else {
    const fileId = `pfile-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const initialVer: FileVersion = {
      id: `pver-${fileId}-1`,
      versionNumber: 1,
      uploadedAt: new Date().toISOString(),
      uploadedBy: {
        id: user.id,
        name: user.name,
        avatar: user.avatar,
        role: 'Proprietário',
      },
      sizeBytes: Number(sizeBytes) || 1024,
      changeSummary: changeSummary || 'Upload inicial do arquivo privado.',
      checksum,
      contentSnippet: content ? content.slice(0, 200) : undefined,
      previewUrl: previewUrl,
    };

    const newFile: WorkspaceFile = {
      id: fileId,
      folderId,
      name,
      originalName: name,
      extension: ext,
      category,
      mimeType: mimeType || 'application/octet-stream',
      sizeBytes: Number(sizeBytes) || 1024,
      currentVersion: 1,
      versions: [initialVer],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      createdBy: {
        id: user.id,
        name: user.name,
        avatar: user.avatar,
        role: 'Proprietário',
      },
      isLocked: false,
      comments: [],
      tags: ['PRIVADO', ext.toUpperCase()],
      content: content || '',
      previewUrl: previewUrl || '',
      isPersonal: true,
      userId: targetUserId,
    };

    personalFiles.push(newFile);
    return res.json({ success: true, file: newFile, isNewVersion: false, versionNumber: 1 });
  }
});

// Revert Personal File
app.post('/api/personal/files/:id/revert', (req, res) => {
  const { id } = req.params;
  const { versionNumber, userId } = req.body;

  const file = personalFiles.find(f => f.id === id);
  if (!file) return res.status(404).json({ error: 'Arquivo pessoal não encontrado.' });

  const targetVersion = file.versions.find(v => v.versionNumber === Number(versionNumber));
  if (!targetVersion) return res.status(404).json({ error: 'Versão não encontrada.' });

  const targetUserId = userId || 'usr-04testes';
  const user = personalUsers.find(u => u.id === targetUserId) || {
    id: targetUserId,
    name: 'Usuário Pessoal',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
  };

  const newVerNum = file.currentVersion + 1;
  const revertVersion: FileVersion = {
    id: `pver-${file.id}-${newVerNum}`,
    versionNumber: newVerNum,
    uploadedAt: new Date().toISOString(),
    uploadedBy: {
      id: user.id,
      name: user.name,
      avatar: user.avatar,
      role: 'Proprietário',
    },
    sizeBytes: targetVersion.sizeBytes,
    changeSummary: `Reversão para a v${versionNumber}.`,
    checksum: targetVersion.checksum,
    contentSnippet: targetVersion.contentSnippet,
    previewUrl: targetVersion.previewUrl || file.previewUrl,
  };

  file.currentVersion = newVerNum;
  file.updatedAt = new Date().toISOString();
  file.sizeBytes = targetVersion.sizeBytes;
  if (targetVersion.previewUrl) file.previewUrl = targetVersion.previewUrl;
  file.versions.push(revertVersion);

  res.json({ success: true, file, currentVersion: newVerNum });
});

// Delete Personal File
app.delete('/api/personal/files/:id', (req, res) => {
  const { id } = req.params;
  const idx = personalFiles.findIndex(f => f.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Arquivo não encontrado.' });

  personalFiles.splice(idx, 1);
  res.json({ success: true });
});

// Clear all sample files and fictitious users (Clean Slate)
app.post('/api/workspace/clear-samples', (req, res) => {
  const { keepDefaultFolder = true } = req.body || {};

  // Clean team data
  db.files = [];
  db.activities = [
    {
      id: `act-${Date.now()}`,
      type: 'sync',
      userId: 'user-current',
      userName: 'Você',
      userAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      targetId: 'workspace',
      targetName: 'Workspace Limpo',
      details: 'Amostras e usuários fictícios foram removidos. Workspace zerado.',
      timestamp: new Date().toISOString(),
    },
  ];

  // Keep only 1 clean default real user
  db.members = [
    {
      id: 'user-current',
      name: 'Você (Administrador)',
      email: '04testes@gmail.com',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      role: 'Administrador',
      status: 'online',
      activeFolderId: 'folder-root',
      lastActive: 'Agora mesmo',
    },
  ];

  if (keepDefaultFolder) {
    db.folders = [
      {
        id: 'folder-root',
        name: '📁 Meus Arquivos',
        description: 'Pasta principal para armazenamento e compartilhamento',
        colorAccent: 'from-cyan-500/30 via-blue-500/20 to-indigo-500/30',
        icon: 'Folder',
        createdAt: new Date().toISOString(),
        createdBy: {
          id: 'user-current',
          name: 'Você',
          avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
        },
        isOpen: true,
        order: 1,
      },
    ];
  } else {
    db.folders = [];
  }

  db.syncState.cloudStorageUsedBytes = 0;
  db.syncState.lastSyncedAt = new Date().toISOString();

  // Also clean personal files
  personalFiles = [];
  if (keepDefaultFolder) {
    personalFolders = [
      {
        id: 'pfolder-root',
        name: '🔒 Cofre Pessoal',
        description: 'Seus arquivos privados protegidos por criptografia',
        colorAccent: 'from-emerald-500/30 via-teal-500/20 to-cyan-500/30',
        icon: 'Shield',
        createdAt: new Date().toISOString(),
        createdBy: {
          id: 'usr-04testes',
          name: '04 Testes',
          avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
        },
        isOpen: true,
        order: 1,
        isPersonal: true,
        userId: 'usr-04testes',
      },
    ];
  } else {
    personalFolders = [];
  }

  broadcast('SYNC_INIT', db);
  res.json({ success: true, message: 'Workspace zerado com sucesso.', workspace: db });
});

// Restore sample demo data
app.post('/api/workspace/restore-samples', (req, res) => {
  db = JSON.parse(JSON.stringify(initialWorkspaceData));
  db.syncState.lastSyncedAt = new Date().toISOString();

  personalFolders = [
    {
      id: 'pfolder-1',
      name: '01. Documentos & Contratos Pessoais',
      description: 'Documentos confidenciais protegidos no cofre pessoal',
      colorAccent: 'from-cyan-500/30 via-blue-500/20 to-indigo-500/30',
      icon: 'FileText',
      createdAt: new Date().toISOString(),
      createdBy: {
        id: 'usr-04testes',
        name: '04 Testes',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      },
      isOpen: true,
      order: 1,
      isPersonal: true,
      userId: 'usr-04testes',
    },
    {
      id: 'pfolder-2',
      name: '02. Projetos Pessoais & Códigos',
      description: 'Rascunhos de código e anotações técnicas privadas',
      colorAccent: 'from-emerald-500/30 via-teal-500/20 to-cyan-500/30',
      icon: 'Code',
      createdAt: new Date().toISOString(),
      createdBy: {
        id: 'usr-04testes',
        name: '04 Testes',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      },
      isOpen: true,
      order: 2,
      isPersonal: true,
      userId: 'usr-04testes',
    },
  ];

  personalFiles = [
    {
      id: 'pfile-1',
      folderId: 'pfolder-1',
      name: 'Anotacoes_Pessoais_Privadas.md',
      originalName: 'Anotacoes_Pessoais_Privadas.md',
      extension: 'md',
      category: 'document',
      mimeType: 'text/markdown',
      sizeBytes: 3420,
      currentVersion: 1,
      versions: [
        {
          id: 'pver-1',
          versionNumber: 1,
          uploadedAt: new Date(Date.now() - 3600000).toISOString(),
          uploadedBy: {
            id: 'usr-04testes',
            name: '04 Testes',
            avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
            role: 'Proprietário',
          },
          sizeBytes: 3420,
          changeSummary: 'Criação inicial do cofre pessoal privado.',
          checksum: 'sha256:p98324f0c9a1e0b',
          contentSnippet: '# Meu Espaço Pessoal\nEste documento está no seu Modo Pessoal...',
        },
      ],
      createdAt: new Date(Date.now() - 3600000).toISOString(),
      updatedAt: new Date(Date.now() - 3600000).toISOString(),
      createdBy: {
        id: 'usr-04testes',
        name: '04 Testes',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
        role: 'Proprietário',
      },
      isLocked: false,
      comments: [],
      tags: ['PRIVADO', 'COFRE'],
      content: `# Meu Espaço Pessoal (Modo Privado)\n\nBem-vindo ao seu cofre e workspace pessoal do CrystalCloud.`,
      isPersonal: true,
      userId: 'usr-04testes',
    },
  ];

  broadcast('SYNC_INIT', db);
  res.json({ success: true, message: 'Dados de demonstração restaurados com sucesso.', workspace: db });
});

// Start Express + Vite
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`CrystalCloud Server + Realtime WebSocket rodando em http://0.0.0.0:${PORT}`);
  });
}

startServer();
