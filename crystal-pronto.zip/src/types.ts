export type FileCategory = 'image' | 'document' | 'code' | 'audio' | 'video' | 'archive' | 'other';
export type WorkspaceScope = 'team' | 'personal';

export interface PersonalUser {
  id: string;
  name: string;
  email: string;
  avatar: string;
  authProvider: 'google' | 'password';
  createdAt: string;
  bgSettings?: {
    imageUrl: string | null;
    zoom: number;
    blur: number;
    overlayOpacity: number;
  };
}

export interface FileVersion {
  id: string;
  versionNumber: number;
  uploadedAt?: string;
  createdAt?: string;
  uploadedBy?: {
    id: string;
    name: string;
    avatar: string;
    role?: string;
  };
  createdBy?: {
    id: string;
    name: string;
    avatar: string;
    role?: string;
  };
  sizeBytes: number;
  changeSummary: string;
  checksum?: string;
  hashChecksum?: string;
  downloadUrl?: string;
  contentSnippet?: string;
  previewUrl?: string;
}

export interface FileComment {
  id: string;
  fileId: string;
  author: {
    id: string;
    name: string;
    avatar: string;
    role?: string;
  };
  content: string;
  createdAt: string;
  resolved?: boolean;
}

export interface WorkspaceFile {
  id: string;
  folderId: string;
  name: string;
  originalName: string;
  extension: string;
  category: FileCategory;
  mimeType: string;
  sizeBytes: number;
  currentVersion: number;
  versions: FileVersion[];
  createdAt: string;
  updatedAt: string;
  createdBy?: {
    id: string;
    name: string;
    avatar: string;
    role?: string;
  };
  updatedBy?: {
    id: string;
    name: string;
    avatar: string;
    role?: string;
  };
  isLocked?: boolean;
  lockedBy?: {
    id: string;
    name: string;
    avatar: string;
  } | null;
  comments: FileComment[];
  tags: string[];
  content?: string; // Text/code/markdown content if applicable
  previewUrl?: string; // Data URL or external image/audio url
  isPersonal?: boolean;
  userId?: string;
}

export interface WorkspaceFolder {
  id: string;
  name: string;
  description: string;
  colorAccent: string; // Tailwind/HEX gradient crystal accent
  icon: string;
  createdAt: string;
  createdBy: {
    id: string;
    name: string;
    avatar: string;
  };
  isOpen: boolean;
  order: number;
  isPersonal?: boolean;
  userId?: string;
}

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: 'Administrador' | 'Editor' | 'Revisor' | 'Visualizador';
  status: 'online' | 'busy' | 'away' | 'offline';
  activeFolderId?: string;
  lastActive: string;
}

export interface ActivityEvent {
  id: string;
  type: 'upload' | 'version_revert' | 'delete' | 'comment' | 'lock' | 'unlock' | 'folder_create' | 'sync';
  userId: string;
  userName: string;
  userAvatar: string;
  targetId: string;
  targetName: string;
  details: string;
  timestamp: string;
}

export interface CloudSyncState {
  status: 'synced' | 'syncing' | 'offline' | 'error';
  lastSyncedAt: string;
  latencyMs: number;
  connectedClients: number;
  serverRegion: string;
  cloudStorageUsedBytes: number;
  cloudStorageLimitBytes: number;
}

export interface WorkspaceData {
  folders: WorkspaceFolder[];
  files: WorkspaceFile[];
  members: TeamMember[];
  activities: ActivityEvent[];
  syncState: CloudSyncState;
  bgSettings?: {
    imageUrl: string | null;
    zoom: number;
    blur: number;
    overlayOpacity: number;
  };
}
