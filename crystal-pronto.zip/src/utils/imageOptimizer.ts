/**
 * Utility to process and optimize background images.
 * Automatically resizes and compresses heavy images to max ~1 Megabyte (1,048,576 bytes)
 * so they load instantly without slowing down the application or memory.
 */

export interface BackgroundSettings {
  imageUrl: string | null;
  zoom: number; // 100 to 200 (%)
  blur: number; // 0 to 20 (px)
  overlayOpacity: number; // 0 to 80 (%)
}

export const DEFAULT_BACKGROUND_SETTINGS: BackgroundSettings = {
  imageUrl: null,
  zoom: 100,
  blur: 0,
  overlayOpacity: 10,
};

export async function compressBackgroundImage(file: File, maxSizeBytes = 1048576): Promise<string> {
  return new Promise((resolve, reject) => {
    // If file is already small (e.g. < 400KB), read directly as data URL
    if (file.size <= 400 * 1024) {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (err) => reject(err);
      reader.readAsDataURL(file);
      return;
    }

    const img = new Image();
    const url = URL.createObjectURL(file);

    img.onload = () => {
      URL.revokeObjectURL(url);

      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;

      // Cap max dimension to 2560px for ultra 2K/4K clarity while staying lightweight
      const MAX_DIMENSION = 2560;
      if (width > MAX_DIMENSION || height > MAX_DIMENSION) {
        if (width > height) {
          height = Math.round((height * MAX_DIMENSION) / width);
          width = MAX_DIMENSION;
        } else {
          width = Math.round((width * MAX_DIMENSION) / height);
          height = MAX_DIMENSION;
        }
      }

      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        // Fallback
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.readAsDataURL(file);
        return;
      }

      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(img, 0, 0, width, height);

      // Attempt compression loop to guarantee < 1MB
      let quality = 0.85;
      let dataUrl = canvas.toDataURL('image/jpeg', quality);

      // Calculate approximate size in bytes from Base64
      let approxSize = Math.round((dataUrl.length * 3) / 4);

      while (approxSize > maxSizeBytes && quality > 0.3) {
        quality -= 0.12;
        dataUrl = canvas.toDataURL('image/jpeg', quality);
        approxSize = Math.round((dataUrl.length * 3) / 4);
      }

      resolve(dataUrl);
    };

    img.onerror = (err) => {
      URL.revokeObjectURL(url);
      reject(err);
    };

    img.src = url;
  });
}
