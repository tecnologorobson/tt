import JSZip from 'jszip';
import { WorkspaceFile, WorkspaceFolder, FileVersion } from '../types';

// Format human-readable byte sizes (B, KB, MB, GB)
export function formatBytes(bytes: number, decimals = 1): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

// Format relative and absolute timestamps
export function formatTimeAgo(isoString: string): string {
  try {
    const date = new Date(isoString);
    const now = new Date();
    const diffSec = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (diffSec < 60) return 'agora mesmo';
    if (diffSec < 3600) return `${Math.floor(diffSec / 60)} min atrás`;
    if (diffSec < 86400) return `${Math.floor(diffSec / 3600)} h atrás`;
    if (diffSec < 604800) return `${Math.floor(diffSec / 86400)} dias atrás`;
    return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
  } catch {
    return isoString;
  }
}

/**
 * Converts a Base64 Data URL to a native binary Uint8Array
 */
export function dataURLtoUint8Array(dataurl: string): { data: Uint8Array; mime: string } {
  try {
    const parts = dataurl.split(',');
    const mimeMatch = parts[0].match(/:(.*?);/);
    const mime = mimeMatch ? mimeMatch[1] : 'application/octet-stream';
    const isBase64 = parts[0].includes('base64');
    
    if (isBase64) {
      const bstr = atob(parts[1] || '');
      let n = bstr.length;
      const u8arr = new Uint8Array(n);
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
      }
      return { data: u8arr, mime };
    } else {
      const decoded = decodeURIComponent(parts[1] || '');
      const encoder = new TextEncoder();
      return { data: encoder.encode(decoded), mime };
    }
  } catch {
    const encoder = new TextEncoder();
    return { data: encoder.encode(dataurl), mime: 'application/octet-stream' };
  }
}

/**
 * Converts a Data URL string directly to a binary Blob
 */
export function dataURLtoBlob(dataurl: string): Blob {
  const { data, mime } = dataURLtoUint8Array(dataurl);
  return new Blob([data.buffer as ArrayBuffer], { type: mime });
}

/**
 * Resolves file payload or URL into an uncorrupted binary/text Blob
 */
export async function resolveFileBlob(file: WorkspaceFile, version?: FileVersion): Promise<Blob> {
  const targetVersion = version || (file.versions && file.versions[file.versions.length - 1]);
  const content = (targetVersion && targetVersion.contentSnippet) || file.content;
  const preview = (targetVersion && targetVersion.previewUrl) || file.previewUrl;
  const mimeType = file.mimeType || 'application/octet-stream';

  // 1. If content is a Data URL (base64 encoded binary or text), convert to binary blob
  if (content && typeof content === 'string' && content.startsWith('data:')) {
    return dataURLtoBlob(content);
  }

  // 2. If previewUrl is a Data URL, convert to binary blob
  if (preview && typeof preview === 'string' && preview.startsWith('data:')) {
    return dataURLtoBlob(preview);
  }

  // 3. If previewUrl is a remote URL (http/https), fetch the actual binary asset
  if (preview && typeof preview === 'string' && (preview.startsWith('http://') || preview.startsWith('https://'))) {
    try {
      const resp = await fetch(preview);
      if (resp.ok) {
        return await resp.blob();
      }
    } catch {
      // fallback
    }
  }

  // 4. If content is a string (e.g. text/code/markdown)
  if (content && typeof content === 'string') {
    return new Blob([content], { type: mimeType });
  }

  // 5. Try fetching from server endpoint
  try {
    const serverUrl = version ? `/api/download/${file.id}?version=${version.versionNumber}` : `/api/download/${file.id}`;
    const resp = await fetch(serverUrl);
    if (resp.ok) {
      return await resp.blob();
    }
  } catch {
    // fallback
  }

  // 6. Final fallback text
  const fallback = `Arquivo: ${file.name}\nVersão: v${file.currentVersion}\nAtualizado: ${file.updatedAt}`;
  return new Blob([fallback], { type: mimeType || 'text/plain;charset=utf-8' });
}

// Download file with IE11 fallback (msSaveOrOpenBlob) and modern anchor fallback
export function triggerFileDownload(filename: string, content: string | Blob | Uint8Array, mimeType = 'application/octet-stream') {
  let blob: Blob;

  if (content instanceof Blob) {
    blob = content;
  } else if (content instanceof Uint8Array) {
    blob = new Blob([content.buffer as ArrayBuffer], { type: mimeType });
  } else if (typeof content === 'string' && content.startsWith('data:')) {
    blob = dataURLtoBlob(content);
  } else if (typeof content === 'string') {
    blob = new Blob([content], { type: mimeType });
  } else {
    blob = new Blob([String(content)], { type: mimeType });
  }

  // 1. IE11 & Legacy Edge navigator fallback
  const nav = window.navigator as any;
  if (nav && typeof nav.msSaveOrOpenBlob === 'function') {
    nav.msSaveOrOpenBlob(blob, filename);
    return;
  }

  // 2. Modern HTML5 Download Attribute
  const blobUrl = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = blobUrl;
  link.download = filename;
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  setTimeout(() => {
    document.body.removeChild(link);
    URL.revokeObjectURL(blobUrl);
  }, 300);
}

/**
 * Downloads a workspace file with zero corruption by resolving its binary content
 */
export async function downloadWorkspaceFile(file: WorkspaceFile, versionNumber?: number) {
  const ver = versionNumber ? file.versions?.find((v) => v.versionNumber === versionNumber) : undefined;
  const blob = await resolveFileBlob(file, ver);
  const targetName = ver && ver.versionNumber !== file.currentVersion
    ? `${file.name.replace(/\.[^/.]+$/, '')}_v${ver.versionNumber}.${file.extension}`
    : file.name;

  triggerFileDownload(targetName, blob, file.mimeType || blob.type);
}

// Generate ZIP of entire folder and trigger download without corrupting binary files
export async function downloadFolderAsZip(folder: WorkspaceFolder, files: WorkspaceFile[]) {
  const zip = new JSZip();
  const folderFiles = files.filter((f) => f.folderId === folder.id);

  // Add manifest
  const manifest = {
    folderName: folder.name,
    description: folder.description,
    exportedAt: new Date().toISOString(),
    totalFiles: folderFiles.length,
    files: folderFiles.map((f) => ({
      name: f.name,
      currentVersion: `v${f.currentVersion}`,
      versionsCount: f.versions?.length || 1,
      size: formatBytes(f.sizeBytes),
      lastUpdated: f.updatedAt,
    })),
  };
  zip.file('_METADATA_WORKSPACE.json', JSON.stringify(manifest, null, 2));

  // Add file contents (handling binary images, pdfs, documents, and code)
  for (const f of folderFiles) {
    try {
      const blob = await resolveFileBlob(f);
      const arrayBuffer = await blob.arrayBuffer();
      zip.file(f.name, arrayBuffer);
    } catch {
      const payload = f.content || `Arquivo: ${f.name}\nVersão: v${f.currentVersion}\nAtualizado em: ${f.updatedAt}`;
      zip.file(f.name, payload);
    }
  }

  const zipBlob = await zip.generateAsync({ type: 'blob' });
  const cleanName = folder.name.replace(/[^a-zA-Z0-9_\-]/g, '_');
  triggerFileDownload(`${cleanName}_CrystalWorkspace.zip`, zipBlob, 'application/zip');
}

// Color and icon helper for categories
export function getCategoryBadge(category: WorkspaceFile['category']) {
  switch (category) {
    case 'code':
      return { label: 'Código', color: 'bg-amber-50 text-amber-800 border-amber-300' };
    case 'document':
      return { label: 'Documento', color: 'bg-emerald-50 text-emerald-800 border-emerald-300' };
    case 'image':
      return { label: 'Imagem', color: 'bg-cyan-50 text-cyan-800 border-cyan-300' };
    case 'audio':
      return { label: 'Áudio', color: 'bg-violet-50 text-violet-800 border-violet-300' };
    case 'video':
      return { label: 'Vídeo', color: 'bg-rose-50 text-rose-800 border-rose-300' };
    case 'archive':
      return { label: 'Arquivo ZIP', color: 'bg-blue-50 text-blue-800 border-blue-300' };
    default:
      return { label: 'Arquivo', color: 'bg-slate-100 text-slate-700 border-slate-300' };
  }
}
