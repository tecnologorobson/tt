import { WorkspaceData } from '../types';

export const initialWorkspaceData: WorkspaceData = {
  folders: [
    {
      id: 'folder-1',
      name: '01. Identidade Visual & UI Cristal',
      description: 'Mockups, paletas de vidro cristalizado, ícones vetoriais e guias de estilo.',
      colorAccent: 'from-cyan-500/30 via-blue-500/20 to-indigo-500/30',
      icon: 'Palette',
      createdAt: '2026-08-20T10:00:00Z',
      createdBy: {
        id: 'user-1',
        name: 'Elena Rostova',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
      },
      isOpen: true,
      order: 1,
    },
    {
      id: 'folder-2',
      name: '02. Documentação & Contratos Técnicos',
      description: 'Especificações de arquitetura, termos de serviço e políticas de sincronização.',
      colorAccent: 'from-emerald-500/30 via-teal-500/20 to-cyan-500/30',
      icon: 'FileText',
      createdAt: '2026-08-22T14:30:00Z',
      createdBy: {
        id: 'user-2',
        name: 'Carlos Mendez',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      },
      isOpen: true,
      order: 2,
    },
    {
      id: 'folder-3',
      name: '03. Scripts & Módulos de Compatibilidade IE11',
      description: 'Polyfills legados, fallbacks CSS com propriedades seguras e shims de WebSocket.',
      colorAccent: 'from-amber-500/30 via-orange-500/20 to-rose-500/30',
      icon: 'Code',
      createdAt: '2026-08-25T09:15:00Z',
      createdBy: {
        id: 'user-3',
        name: 'Akira Tanaka',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
      },
      isOpen: true,
      order: 3,
    },
    {
      id: 'folder-4',
      name: '04. Relatórios de Performance & Nuvem',
      description: 'Métricas de latência, relatórios de throughput de sincronização e telemetria.',
      colorAccent: 'from-violet-500/30 via-purple-500/20 to-pink-500/30',
      icon: 'BarChart3',
      createdAt: '2026-08-28T16:45:00Z',
      createdBy: {
        id: 'user-4',
        name: 'Sofia Alencar',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      },
      isOpen: true,
      order: 4,
    },
  ],
  files: [
    {
      id: 'file-101',
      folderId: 'folder-1',
      name: 'Guia_Estilo_Cristal_v3.md',
      originalName: 'Guia_Estilo_Cristal_v3.md',
      extension: 'md',
      category: 'document',
      mimeType: 'text/markdown',
      sizeBytes: 18400,
      currentVersion: 3,
      createdAt: '2026-08-20T11:00:00Z',
      updatedAt: '2026-08-29T07:30:00Z',
      createdBy: {
        id: 'user-1',
        name: 'Elena Rostova',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
        role: 'Designer Chefe',
      },
      isLocked: false,
      tags: ['Design System', 'Squircles', 'UI Glass'],
      content: `# Sistema de Design Cristalino (Crystal Glassmorphism)

## 1. Princípios Geométricos dos Squircles
- **Raio de Borda**: 24px a 28px nos cartões principais.
- **Efeito Cristalizado**: Combinação de \`backdrop-filter: blur(16px)\`, borda de 1px com degradê especular (\`linear-gradient(135deg, rgba(255,255,255,0.4), rgba(255,255,255,0.05))\`) e sombra difusa.

## 2. Fallbacks Obrigatórios para Internet Explorer 11
- Em navegadores sem suporte a \`backdrop-filter\`, aplicar fundo sólido RGBA (\`background-color: #1e293b\` ou \`rgba(30, 41, 59, 0.95)\`).
- Prefixos \`-ms-\` para alinhamento Flexbox e Grid legacy.

## 3. Paleta de Cores
- **Ciano Cristal**: #06b6d4
- **Vidro Fosco Profundo**: #0f172a / #1e293b
- **Brilho Especular**: rgba(255, 255, 255, 0.75)`,
      versions: [
        {
          id: 'ver-101-1',
          versionNumber: 1,
          uploadedAt: '2026-08-20T11:00:00Z',
          uploadedBy: {
            id: 'user-1',
            name: 'Elena Rostova',
            avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
            role: 'Designer Chefe',
          },
          sizeBytes: 11200,
          changeSummary: 'Criação inicial do rascunho de especificações visuais.',
          checksum: 'sha256:7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069',
          contentSnippet: '# Sistema de Design Cristalino\nVersão inicial sem fallbacks IE11.',
        },
        {
          id: 'ver-101-2',
          versionNumber: 2,
          uploadedAt: '2026-08-24T15:20:00Z',
          uploadedBy: {
            id: 'user-3',
            name: 'Akira Tanaka',
            avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
            role: 'Arquiteto Frontend',
          },
          sizeBytes: 15100,
          changeSummary: 'Adicionados tópicos de compatibilidade IE11 e prefixos -ms.',
          checksum: 'sha256:3b64db6bc9ced309354e5b6a3b2b415a7704df39c4d9a7dc9230538a72f0f8c0',
          contentSnippet: '# Sistema de Design Cristalino\nAdicionado suporte a fallbacks.',
        },
        {
          id: 'ver-101-3',
          versionNumber: 3,
          uploadedAt: '2026-08-29T07:30:00Z',
          uploadedBy: {
            id: 'user-1',
            name: 'Elena Rostova',
            avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
            role: 'Designer Chefe',
          },
          sizeBytes: 18400,
          changeSummary: 'Refinamento das cores primárias e tabelas de contraste AA.',
          checksum: 'sha256:9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08',
          contentSnippet: '# Sistema de Design Cristalino (Crystal Glassmorphism)\nVersão final aprovada.',
        },
      ],
      comments: [
        {
          id: 'comm-1',
          fileId: 'file-101',
          author: {
            id: 'user-3',
            name: 'Akira Tanaka',
            avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
            role: 'Arquiteto Frontend',
          },
          content: 'Os fallbacks para IE11 ficaram perfeitos com os gradientes sólidos alternativos!',
          createdAt: '2026-08-29T07:45:00Z',
        },
        {
          id: 'comm-2',
          fileId: 'file-101',
          author: {
            id: 'user-4',
            name: 'Sofia Alencar',
            avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
            role: 'Product Manager',
          },
          content: 'Aprovado para a sincronização da sprint.',
          createdAt: '2026-08-29T08:00:00Z',
        },
      ],
    },
    {
      id: 'file-102',
      folderId: 'folder-1',
      name: 'Squircle_Crystal_Hero.png',
      originalName: 'Squircle_Crystal_Hero.png',
      extension: 'png',
      category: 'image',
      mimeType: 'image/png',
      sizeBytes: 245000,
      currentVersion: 2,
      createdAt: '2026-08-21T08:30:00Z',
      updatedAt: '2026-08-27T10:15:00Z',
      createdBy: {
        id: 'user-1',
        name: 'Elena Rostova',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
        role: 'Designer Chefe',
      },
      previewUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80',
      isLocked: false,
      tags: ['Artwork', 'Hero', 'Crystal'],
      versions: [
        {
          id: 'ver-102-1',
          versionNumber: 1,
          uploadedAt: '2026-08-21T08:30:00Z',
          uploadedBy: {
            id: 'user-1',
            name: 'Elena Rostova',
            avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
            role: 'Designer Chefe',
          },
          sizeBytes: 198000,
          changeSummary: 'Renderização 3D inicial de vidro fosco.',
          checksum: 'sha256:5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8',
        },
        {
          id: 'ver-102-2',
          versionNumber: 2,
          uploadedAt: '2026-08-27T10:15:00Z',
          uploadedBy: {
            id: 'user-1',
            name: 'Elena Rostova',
            avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
            role: 'Designer Chefe',
          },
          sizeBytes: 245000,
          changeSummary: 'Maior refração e realce especular de luz.',
          checksum: 'sha256:4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a',
        },
      ],
      comments: [],
    },
    {
      id: 'file-201',
      folderId: 'folder-2',
      name: 'Arquitetura_Sincronizacao_Nuvem.json',
      originalName: 'Arquitetura_Sincronizacao_Nuvem.json',
      extension: 'json',
      category: 'code',
      mimeType: 'application/json',
      sizeBytes: 8900,
      currentVersion: 4,
      createdAt: '2026-08-22T15:00:00Z',
      updatedAt: '2026-08-29T06:10:00Z',
      createdBy: {
        id: 'user-2',
        name: 'Carlos Mendez',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        role: 'Tech Lead Cloud',
      },
      isLocked: true,
      lockedBy: {
        id: 'user-2',
        name: 'Carlos Mendez',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      },
      tags: ['Cloud Sync', 'WebSockets', 'Protocol'],
      content: JSON.stringify(
        {
          syncEngine: 'CrystalCloud-Realtime-v4',
          transport: ['WebSocket', 'HTTP/2-Streaming', 'Long-Polling-IE11-Fallback'],
          replication: {
            strategy: 'Server-Authoritative-Event-Stream',
            conflictResolution: 'Automatic-Versioning-Timestamp-LWW',
            heartbeatIntervalMs: 5000,
            autoReconnect: true,
            maxBackoffMs: 30000,
          },
          security: {
            encryption: 'AES-256-GCM',
            checksumAlgo: 'SHA-256',
            tokenExpiryMinutes: 1440,
          },
          legacyCompatibility: {
            internetExplorer11: {
              activeXObjectFallback: true,
              jsonPolyfill: 'Builtin-ES5',
              corsShim: 'XDomainRequest-Safe',
            },
          },
        },
        null,
        2
      ),
      versions: [
        {
          id: 'ver-201-1',
          versionNumber: 1,
          uploadedAt: '2026-08-22T15:00:00Z',
          uploadedBy: {
            id: 'user-2',
            name: 'Carlos Mendez',
            avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
            role: 'Tech Lead Cloud',
          },
          sizeBytes: 4200,
          changeSummary: 'Esquema preliminar de comunicação REST.',
          checksum: 'sha256:ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d',
        },
        {
          id: 'ver-201-2',
          versionNumber: 2,
          uploadedAt: '2026-08-24T10:00:00Z',
          uploadedBy: {
            id: 'user-2',
            name: 'Carlos Mendez',
            avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
            role: 'Tech Lead Cloud',
          },
          sizeBytes: 6100,
          changeSummary: 'Inclusão do protocolo WebSocket para sincronização contínua.',
          checksum: 'sha256:2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef9f8bde73a1e',
        },
        {
          id: 'ver-201-3',
          versionNumber: 3,
          uploadedAt: '2026-08-26T14:40:00Z',
          uploadedBy: {
            id: 'user-3',
            name: 'Akira Tanaka',
            avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
            role: 'Arquiteto Frontend',
          },
          sizeBytes: 7800,
          changeSummary: 'Configurado fallback de polling e headers legados para IE11.',
          checksum: 'sha256:0ffe1abd1a08215353c233d6e009613e95eec4253832a761af28ff37ac5a150c',
        },
        {
          id: 'ver-201-4',
          versionNumber: 4,
          uploadedAt: '2026-08-29T06:10:00Z',
          uploadedBy: {
            id: 'user-2',
            name: 'Carlos Mendez',
            avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
            role: 'Tech Lead Cloud',
          },
          sizeBytes: 8900,
          changeSummary: 'Adicionados parâmetros de criptografia AES-256 e timeout de lock.',
          checksum: 'sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
        },
      ],
      comments: [
        {
          id: 'comm-201-1',
          fileId: 'file-201',
          author: {
            id: 'user-2',
            name: 'Carlos Mendez',
            avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
            role: 'Tech Lead Cloud',
          },
          content: 'Arquivo bloqueado temporariamente para ajustes de segurança.',
          createdAt: '2026-08-29T06:15:00Z',
        },
      ],
    },
    {
      id: 'file-301',
      folderId: 'folder-3',
      name: 'ie11_glass_and_sync_polyfill.js',
      originalName: 'ie11_glass_and_sync_polyfill.js',
      extension: 'js',
      category: 'code',
      mimeType: 'text/javascript',
      sizeBytes: 12600,
      currentVersion: 2,
      createdAt: '2026-08-25T10:00:00Z',
      updatedAt: '2026-08-28T18:00:00Z',
      createdBy: {
        id: 'user-3',
        name: 'Akira Tanaka',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
        role: 'Arquiteto Frontend',
      },
      isLocked: false,
      tags: ['IE11', 'Polyfill', 'Legacy', 'Compatibility'],
      content: `/**
 * CrystalCloud IE11 Compatibility & Glassmorphism Fallback Layer
 * Ensures seamless operation on Internet Explorer 11, Edge Legacy, and modern browsers.
 */

(function (window, document) {
  'use strict';

  // 1. Detect CSS backdrop-filter support
  var supportsBackdrop = false;
  if (typeof CSS !== 'undefined' && CSS.supports) {
    supportsBackdrop = CSS.supports('backdrop-filter', 'blur(10px)') || 
                       CSS.supports('-webkit-backdrop-filter', 'blur(10px)');
  }

  // 2. Apply legacy class if unsupported
  if (!supportsBackdrop) {
    document.documentElement.className += ' ie11-no-backdrop-filter';
  }

  // 3. Object.assign Polyfill for IE11
  if (typeof Object.assign !== 'function') {
    Object.assign = function (target) {
      if (target === undefined || target === null) {
        throw new TypeError('Cannot convert undefined or null to object');
      }
      var output = Object(target);
      for (var index = 1; index < arguments.length; index++) {
        var source = arguments[index];
        if (source !== undefined && source !== null) {
          for (var nextKey in source) {
            if (Object.prototype.hasOwnProperty.call(source, nextKey)) {
              output[nextKey] = source[nextKey];
            }
          }
        }
      }
      return output;
    };
  }

  // 4. CustomEvent Polyfill for IE11
  if (typeof window.CustomEvent !== 'function') {
    function CustomEvent(event, params) {
      params = params || { bubbles: false, cancelable: false, detail: null };
      var evt = document.createEvent('CustomEvent');
      evt.initCustomEvent(event, params.bubbles, params.cancelable, params.detail);
      return evt;
    }
    window.CustomEvent = CustomEvent;
  }

  console.log('[CrystalCloud] IE11 Compatibility Engine Initialized.');
})(window, document);`,
      versions: [
        {
          id: 'ver-301-1',
          versionNumber: 1,
          uploadedAt: '2026-08-25T10:00:00Z',
          uploadedBy: {
            id: 'user-3',
            name: 'Akira Tanaka',
            avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
            role: 'Arquiteto Frontend',
          },
          sizeBytes: 7400,
          changeSummary: 'Primeira versão do polyfill de backdrop-filter e CustomEvent.',
          checksum: 'sha256:1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b',
        },
        {
          id: 'ver-301-2',
          versionNumber: 2,
          uploadedAt: '2026-08-28T18:00:00Z',
          uploadedBy: {
            id: 'user-3',
            name: 'Akira Tanaka',
            avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
            role: 'Arquiteto Frontend',
          },
          sizeBytes: 12600,
          changeSummary: 'Adicionados shims para Object.assign e classes legacy globais.',
          checksum: 'sha256:9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4d3e2f1a0b9c8d7e6f5a4b3c2d1e0f9a8b',
        },
      ],
      comments: [],
    },
    {
      id: 'file-401',
      folderId: 'folder-4',
      name: 'Relatorio_SLA_e_Latencia_Agosto.md',
      originalName: 'Relatorio_SLA_e_Latencia_Agosto.md',
      extension: 'md',
      category: 'document',
      mimeType: 'text/markdown',
      sizeBytes: 9400,
      currentVersion: 1,
      createdAt: '2026-08-28T17:00:00Z',
      updatedAt: '2026-08-28T17:00:00Z',
      createdBy: {
        id: 'user-4',
        name: 'Sofia Alencar',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        role: 'Product Manager',
      },
      isLocked: false,
      tags: ['SLA', 'Metrics', 'Cloud'],
      content: `# Relatório Executivo de Sincronização em Tempo Real

## Desempenho no Cluster
- **Tempo Médio de Sincronização**: 14ms (P95: 22ms)
- **Taxa de Sucesso de Upload**: 99.98%
- **Compressão Automática de Versões**: Redução média de 42% no tráfego de rede
- **Disponibilidade Global (SLA)**: 99.995%

## Resumo de Versionamento Automático
Durante o ciclo atual, foram processadas **1.420 revisões incrementais** sem nenhuma colisão de escrita, graças ao sistema de trava colaborativa (lock/checkout) e rastreamento por checksum SHA-256.`,
      versions: [
        {
          id: 'ver-401-1',
          versionNumber: 1,
          uploadedAt: '2026-08-28T17:00:00Z',
          uploadedBy: {
            id: 'user-4',
            name: 'Sofia Alencar',
            avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
            role: 'Product Manager',
          },
          sizeBytes: 9400,
          changeSummary: 'Publicação consolidada do relatório de agosto.',
          checksum: 'sha256:7c4a8d09ca3762af61e59520943dc26494f8941b',
        },
      ],
      comments: [],
    },
  ],
  members: [
    {
      id: 'user-current',
      name: 'Você (Colaborador Ativo)',
      email: '04testes@gmail.com',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      role: 'Administrador',
      status: 'online',
      activeFolderId: 'folder-1',
      lastActive: 'Agora mesmo',
    },
    {
      id: 'user-1',
      name: 'Elena Rostova',
      email: 'elena.rostova@crystalcloud.io',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
      role: 'Editor',
      status: 'online',
      activeFolderId: 'folder-1',
      lastActive: '1 min atrás',
    },
    {
      id: 'user-2',
      name: 'Carlos Mendez',
      email: 'carlos.mendez@crystalcloud.io',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      role: 'Editor',
      status: 'busy',
      activeFolderId: 'folder-2',
      lastActive: '3 min atrás',
    },
    {
      id: 'user-3',
      name: 'Akira Tanaka',
      email: 'akira.tanaka@crystalcloud.io',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
      role: 'Revisor',
      status: 'online',
      activeFolderId: 'folder-3',
      lastActive: '5 min atrás',
    },
    {
      id: 'user-4',
      name: 'Sofia Alencar',
      email: 'sofia.alencar@crystalcloud.io',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      role: 'Visualizador',
      status: 'away',
      activeFolderId: 'folder-4',
      lastActive: '22 min atrás',
    },
  ],
  activities: [
    {
      id: 'act-1',
      type: 'upload',
      userId: 'user-1',
      userName: 'Elena Rostova',
      userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
      targetId: 'file-101',
      targetName: 'Guia_Estilo_Cristal_v3.md',
      details: 'Criou automaticamente a versão v3 com novas paletas de vidro cristalizado.',
      timestamp: '2026-08-29T07:30:00Z',
    },
    {
      id: 'act-2',
      type: 'lock',
      userId: 'user-2',
      userName: 'Carlos Mendez',
      userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      targetId: 'file-201',
      targetName: 'Arquitetura_Sincronizacao_Nuvem.json',
      details: 'Bloqueou o arquivo para edição de segurança.',
      timestamp: '2026-08-29T06:15:00Z',
    },
    {
      id: 'act-3',
      type: 'sync',
      userId: 'system',
      userName: 'CrystalCloud Sync Daemon',
      userAvatar: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
      targetId: 'workspace-root',
      targetName: 'Workspace Nuvem',
      details: 'Sincronização em tempo real ativa (Latência 16ms).',
      timestamp: '2026-08-29T08:10:00Z',
    },
  ],
  syncState: {
    status: 'synced',
    lastSyncedAt: new Date().toISOString(),
    latencyMs: 16,
    connectedClients: 5,
    serverRegion: 'us-west1 (Cloud Run Edge)',
    cloudStorageUsedBytes: 285300,
    cloudStorageLimitBytes: 10737418240, // 10 GB
  },
  bgSettings: {
    imageUrl: null,
    zoom: 100,
    blur: 0,
    overlayOpacity: 10,
  },
};
