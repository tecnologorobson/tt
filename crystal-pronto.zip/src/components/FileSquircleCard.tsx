import React, { useState } from 'react';
import {
  FileText,
  FileCode,
  Image,
  Film,
  Music,
  Archive,
  Download,
  Eye,
  History,
  Lock,
  Unlock,
  MessageSquare,
  Trash2,
  Check,
  Sparkles,
} from 'lucide-react';
import { WorkspaceFile, TeamMember } from '../types';
import { formatBytes, formatTimeAgo, downloadWorkspaceFile, getCategoryBadge } from '../utils/fileUtils';

interface FileSquircleCardProps {
  file: WorkspaceFile;
  activeMember: TeamMember;
  onPreview: (file: WorkspaceFile) => void;
  onOpenVersions: (file: WorkspaceFile) => void;
  onToggleLock: (file: WorkspaceFile) => void;
  onOpenComments: (file: WorkspaceFile) => void;
  onDelete: (file: WorkspaceFile) => void;
}

export const FileSquircleCard: React.FC<FileSquircleCardProps> = ({
  file,
  activeMember,
  onPreview,
  onOpenVersions,
  onToggleLock,
  onOpenComments,
  onDelete,
}) => {
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const badge = getCategoryBadge(file.category);

  const getIcon = () => {
    switch (file.category) {
      case 'code':
        return <FileCode className="w-5 h-5 text-amber-600" />;
      case 'image':
        return <Image className="w-5 h-5 text-cyan-600" />;
      case 'video':
        return <Film className="w-5 h-5 text-rose-600" />;
      case 'audio':
        return <Music className="w-5 h-5 text-violet-600" />;
      case 'archive':
        return <Archive className="w-5 h-5 text-blue-600" />;
      default:
        return <FileText className="w-5 h-5 text-emerald-600" />;
    }
  };

  const handleDownload = async (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsDownloading(true);
    try {
      await downloadWorkspaceFile(file);
    } catch {
      // fallback
    }

    setTimeout(() => {
      setIsDownloading(false);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 1800);
    }, 250);
  };

  return (
    <div
      id={`file-card-${file.id}`}
      className="crystal-squircle-sm p-3 flex flex-col justify-between group hover:border-cyan-400 hover:shadow-md transition-all duration-200 relative overflow-hidden"
    >
      <div className="space-y-2">
        {/* Top Header in Card */}
        <div className="flex items-center justify-between gap-1.5">
          <span className={`text-[10px] px-2 py-0.5 rounded-md font-semibold border ${badge.color}`}>
            {badge.label}
          </span>

          <div className="flex items-center gap-1">
            {/* Lock Status */}
            {file.isLocked && (
              <span
                className="p-1 rounded-md bg-amber-50 text-amber-700 border border-amber-200"
                title={`Bloqueado para edição por ${file.lockedBy?.name || 'outro usuário'}`}
              >
                <Lock className="w-3 h-3" />
              </span>
            )}

            {/* Version Badge (clickable for history) */}
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onOpenVersions(file);
              }}
              className="flex items-center gap-0.5 text-[10px] font-mono px-1.5 py-0.5 rounded-md bg-cyan-50 text-cyan-800 border border-cyan-200 hover:bg-cyan-100 transition-colors font-bold cursor-pointer"
              title="Histórico de versões e revisões"
            >
              <History className="w-2.5 h-2.5 text-cyan-600" />
              <span>v{file.currentVersion}</span>
            </button>
          </div>
        </div>

        {/* Thumbnail Preview or Icon Display */}
        {file.previewUrl ? (
          <div
            onClick={() => onPreview(file)}
            className="w-full h-24 rounded-xl overflow-hidden bg-slate-100 border border-slate-200 relative cursor-pointer group-hover:opacity-95"
          >
            <img
              src={file.previewUrl}
              alt={file.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          </div>
        ) : (
          <div
            onClick={() => onPreview(file)}
            className="w-full h-20 rounded-xl bg-slate-50 border border-slate-200 flex flex-col items-center justify-center cursor-pointer group-hover:bg-cyan-50/50 transition-colors"
          >
            <div className="p-2 rounded-xl bg-white border border-slate-200 shadow-2xs group-hover:scale-110 transition-transform">
              {getIcon()}
            </div>
            <span className="text-[10px] font-mono text-slate-400 mt-1 uppercase">.{file.extension}</span>
          </div>
        )}

        {/* File Name & Meta */}
        <div>
          <h4
            onClick={() => onPreview(file)}
            className="text-xs font-bold text-slate-900 truncate group-hover:text-cyan-700 transition-colors cursor-pointer"
            title={file.name}
          >
            {file.name}
          </h4>

          <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono mt-1">
            <span>{formatBytes(file.sizeBytes)}</span>
            <span className="text-[10px] font-sans text-slate-400">{formatTimeAgo(file.updatedAt)}</span>
          </div>
        </div>
      </div>

      {/* Card Action Footer */}
      <div className="pt-2 mt-2 border-t border-slate-200/80 flex items-center justify-between gap-1">
        {/* Author / Synced Avatar */}
        {(() => {
          const author = file.updatedBy || file.createdBy || {
            name: 'Membro',
            avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
          };
          const authorName = author.name || 'Membro';
          const authorAvatar =
            author.avatar ||
            'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80';
          return (
            <div className="flex items-center gap-1.5 min-w-0" title={`Atualizado por ${authorName}`}>
              <img
                src={authorAvatar}
                alt={authorName}
                className="w-4 h-4 rounded-full object-cover ring-1 ring-slate-300 shrink-0"
              />
              <span className="text-[10px] text-slate-500 truncate max-w-[60px]">{authorName.split(' ')[0]}</span>
            </div>
          );
        })()}

        {/* Action Buttons */}
        <div className="flex items-center gap-1">
          {/* Comments */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onOpenComments(file);
            }}
            className="p-1 rounded-md text-slate-500 hover:text-cyan-700 hover:bg-cyan-50 transition-colors relative cursor-pointer"
            title={`${file.comments.length} comentários`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            {file.comments.length > 0 && (
              <span className="absolute -top-1 -right-1 px-1 text-[9px] font-bold rounded-full bg-cyan-600 text-white font-mono leading-none">
                {file.comments.length}
              </span>
            )}
          </button>

          {/* Quick Preview */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onPreview(file);
            }}
            className="p-1 rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
            title="Visualizar / Editar"
          >
            <Eye className="w-3.5 h-3.5" />
          </button>

          {/* Download Button */}
          <button
            id={`btn-download-${file.id}`}
            type="button"
            onClick={handleDownload}
            disabled={isDownloading}
            className={`p-1 px-1.5 rounded-md text-xs font-semibold flex items-center gap-0.5 transition-all cursor-pointer ${
              downloadSuccess
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-300'
                : 'bg-cyan-50 text-cyan-800 hover:bg-cyan-100 border border-cyan-200 shadow-2xs'
            }`}
            title="Download com suporte a IE11 / Legados"
          >
            {downloadSuccess ? (
              <Check className="w-3.5 h-3.5 text-emerald-600" />
            ) : (
              <Download className="w-3.5 h-3.5" />
            )}
          </button>

          {/* Delete Option */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onDelete(file);
            }}
            className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
            title="Excluir arquivo"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
