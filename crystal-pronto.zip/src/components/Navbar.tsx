import React from 'react';
import {
  Upload,
  FolderPlus,
  Layers,
  Shield,
  Lock,
} from 'lucide-react';
import { CloudSyncState, TeamMember, WorkspaceScope, PersonalUser } from '../types';

interface NavbarProps {
  syncState: CloudSyncState;
  members: TeamMember[];
  workspaceScope: WorkspaceScope;
  setWorkspaceScope: (scope: WorkspaceScope) => void;
  personalUser: PersonalUser | null;
  onOpenAuthModal: () => void;
  onLogoutPersonal: () => void;
  onOpenUpload: () => void;
  onOpenNewFolder: () => void;
  onOpenInfoHub: () => void;
  onOpenTeam: () => void;
  onOpenIE11Modal: () => void;
  onForceSync: () => void;
  isIE11Mode: boolean;
  activeMember: TeamMember;
  onSelectMember: (member: TeamMember) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  syncState,
  workspaceScope,
  setWorkspaceScope,
  personalUser,
  onOpenAuthModal,
  onOpenUpload,
  onOpenNewFolder,
  onOpenInfoHub,
  activeMember,
}) => {
  const handleScopeChange = (targetScope: WorkspaceScope) => {
    if (targetScope === 'personal' && !personalUser) {
      onOpenAuthModal();
      return;
    }
    setWorkspaceScope(targetScope);
  };

  const currentUserAvatar =
    workspaceScope === 'personal' && personalUser
      ? personalUser.avatar
      : activeMember?.avatar ||
        'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80';

  const currentUserName =
    workspaceScope === 'personal' && personalUser
      ? personalUser.name
      : activeMember?.name || 'Administrador';

  // Connection indicator status color (solid dot, no ping animation)
  const connectionDotColor =
    syncState.status === 'synced'
      ? 'bg-emerald-500 ring-2 ring-white shadow-xs'
      : syncState.status === 'syncing'
      ? 'bg-amber-400 ring-2 ring-white shadow-xs'
      : 'bg-rose-500 ring-2 ring-white shadow-xs';

  const connectionTitle =
    syncState.status === 'synced'
      ? `Conectado (${syncState.latencyMs}ms)`
      : syncState.status === 'syncing'
      ? 'Sincronizando com a nuvem...'
      : 'Desconectado / Erro de sincronização';

  return (
    <header className="sticky top-0 z-40 w-full px-3 sm:px-6 py-2 sm:py-2.5 border-b border-slate-200/50 bg-white/60 backdrop-blur-xl transition-all shadow-xs">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 sm:gap-4">
        {/* User Avatar Hub Trigger & Workspace Name */}
        <div className="flex items-center gap-2.5 sm:gap-3">
          <button
            id="btn-user-avatar-hub"
            type="button"
            onClick={onOpenInfoHub}
            className="group relative flex items-center justify-center w-10 h-10 sm:w-11 sm:h-11 rounded-2xl p-0.5 bg-gradient-to-tr from-cyan-600 to-blue-600 shadow-md shadow-cyan-600/20 shrink-0 hover:scale-105 active:scale-95 transition-all cursor-pointer ring-1 ring-white/60"
            title={`Perfil: ${currentUserName} • Clique para abrir opções e armazenamento`}
            aria-label="Abrir Perfil e Central de Opções"
          >
            <img
              src={currentUserAvatar}
              alt={currentUserName}
              className="w-full h-full rounded-[14px] object-cover bg-white"
            />
            {/* Solid Connection Status Dot (Green = Connected, Red = Disconnected) */}
            <span
              className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full ${connectionDotColor}`}
              title={connectionTitle}
            />
          </button>

          <div className="flex flex-col">
            <button
              type="button"
              onClick={onOpenInfoHub}
              className="text-left flex items-center gap-1.5 cursor-pointer group"
            >
              <h1 className="text-base sm:text-lg font-extrabold tracking-tight text-slate-900 group-hover:text-cyan-700 transition-colors">
                CrystalCloud
              </h1>
            </button>
            <span className="text-[10px] sm:text-[11px] text-slate-500 font-medium truncate max-w-[170px] sm:max-w-xs">
              {workspaceScope === 'team' ? 'Espaço de Equipe' : 'Cofre Pessoal'} • {currentUserName.split(' ')[0]}
            </span>
          </div>
        </div>

        {/* Center Mode Switcher (Equipe / Pessoal) */}
        <div className="hidden md:flex items-center p-1 rounded-2xl bg-white/70 backdrop-blur-md border border-slate-200/80 shadow-2xs">
          <button
            id="btn-switch-team-workspace"
            type="button"
            onClick={() => handleScopeChange('team')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              workspaceScope === 'team'
                ? 'bg-white text-cyan-900 border border-cyan-300 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-cyan-600" />
            <span>Equipe</span>
          </button>

          <button
            id="btn-switch-personal-mode"
            type="button"
            onClick={() => handleScopeChange('personal')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              workspaceScope === 'personal'
                ? 'bg-white text-emerald-900 border border-emerald-300 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {personalUser ? (
              <Shield className="w-3.5 h-3.5 text-emerald-600" />
            ) : (
              <Lock className="w-3.5 h-3.5 text-amber-600" />
            )}
            <span>Modo Pessoal</span>
          </button>
        </div>

        {/* Action Buttons: Clean & Direct */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* New Folder Action */}
          <button
            id="btn-quick-new-folder"
            type="button"
            onClick={onOpenNewFolder}
            className="flex items-center gap-1.5 px-3 py-2 sm:px-3.5 sm:py-2 rounded-xl text-xs font-bold text-slate-700 bg-white/80 hover:bg-white border border-slate-200 shadow-2xs transition-all cursor-pointer min-h-[38px]"
            title="Criar nova pasta aberta"
          >
            <FolderPlus className="w-4 h-4 text-cyan-700" />
            <span className="hidden sm:inline">Nova Pasta</span>
          </button>

          {/* Primary Upload Action */}
          <button
            id="btn-main-upload-trigger"
            type="button"
            onClick={onOpenUpload}
            className="flex items-center gap-1.5 px-3.5 py-2 sm:px-4 sm:py-2 rounded-xl text-xs sm:text-sm font-bold text-white bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 shadow-sm shadow-cyan-600/20 active:scale-95 transition-all cursor-pointer min-h-[38px]"
            title="Enviar arquivo para o espaço aberto"
          >
            <Upload className="w-4 h-4" />
            <span>Enviar Arquivo</span>
          </button>
        </div>
      </div>
    </header>
  );
};

