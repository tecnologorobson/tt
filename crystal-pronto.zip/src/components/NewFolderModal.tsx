import React, { useState } from 'react';
import { X, FolderPlus, Palette, FileText, Code, BarChart3, Shield } from 'lucide-react';

interface NewFolderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateFolder: (name: string, description: string, colorAccent: string, icon: string) => Promise<void>;
}

export const NewFolderModal: React.FC<NewFolderModalProps> = ({ isOpen, onClose, onCreateFolder }) => {
  if (!isOpen) return null;

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [selectedColor, setSelectedColor] = useState('from-cyan-500 via-blue-500 to-indigo-500');
  const [selectedIcon, setSelectedIcon] = useState('Palette');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const colors = [
    { label: 'Ciano & Azul Cristal', value: 'from-cyan-500 via-blue-500 to-indigo-500' },
    { label: 'Esmeralda & Turquesa', value: 'from-emerald-500 via-teal-500 to-cyan-500' },
    { label: 'Âmbar & Dourado Solar', value: 'from-amber-500 via-orange-500 to-rose-500' },
    { label: 'Violeta & Púrpura Neon', value: 'from-violet-500 via-purple-500 to-pink-500' },
    { label: 'Rosa & Magenta Aurora', value: 'from-rose-500 via-pink-500 to-amber-500' },
  ];

  const icons = [
    { id: 'Palette', label: 'Design & UI', icon: <Palette className="w-4 h-4" /> },
    { id: 'FileText', label: 'Documentos', icon: <FileText className="w-4 h-4" /> },
    { id: 'Code', label: 'Scripts & Dev', icon: <Code className="w-4 h-4" /> },
    { id: 'BarChart3', label: 'Métricas & Data', icon: <BarChart3 className="w-4 h-4" /> },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setIsSubmitting(true);
    await onCreateFolder(name.trim(), description.trim(), selectedColor, selectedIcon);
    setIsSubmitting(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        id="modal-new-folder"
        className="crystal-squircle w-full max-w-lg bg-white/95 border border-slate-200 shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-100 border border-cyan-200 flex items-center justify-center text-cyan-700">
              <FolderPlus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">Criar Nova Pasta Aberta</h3>
              <p className="text-xs text-slate-500">Organize seus arquivos em uma nova bandeja cristalizada</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Nome da Pasta *
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: 05. Especificações de Produto..."
              className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-white border border-slate-300 rounded-xl text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-cyan-500"
              required
              autoFocus
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Descrição do Conteúdo
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Ex: Guias de sprint, modelos e especificações técnicas..."
              className="w-full px-3.5 py-2 text-xs bg-white border border-slate-300 rounded-xl text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Color Accent */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Gradiente Cristal de Destaque
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {colors.map((c, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setSelectedColor(c.value)}
                  className={`p-2 rounded-xl border text-xs text-left flex items-center gap-2 transition-all cursor-pointer ${
                    selectedColor === c.value
                      ? 'border-cyan-500 bg-cyan-50 text-cyan-900 font-semibold shadow-2xs'
                      : 'border-slate-200 bg-slate-50 text-slate-700 hover:border-slate-300 hover:bg-white'
                  }`}
                >
                  <div className={`w-4 h-4 rounded-full bg-gradient-to-r ${c.value} border border-white`} />
                  <span className="truncate">{c.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Icon Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Ícone Temático
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {icons.map((ic) => (
                <button
                  key={ic.id}
                  type="button"
                  onClick={() => setSelectedIcon(ic.id)}
                  className={`p-2.5 rounded-xl border text-xs flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                    selectedIcon === ic.id
                      ? 'border-cyan-500 bg-cyan-50 text-cyan-900 font-semibold shadow-2xs'
                      : 'border-slate-200 bg-slate-50 text-slate-600 hover:border-slate-300 hover:bg-white'
                  }`}
                >
                  {ic.icon}
                  <span className="text-[11px]">{ic.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="pt-3 border-t border-slate-200 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-100 rounded-xl"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={!name.trim() || isSubmitting}
              className="px-5 py-2 text-xs font-semibold text-white bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 rounded-xl shadow-xs disabled:opacity-50"
            >
              {isSubmitting ? 'Criando Pasta...' : 'Criar Pasta Aberta'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
