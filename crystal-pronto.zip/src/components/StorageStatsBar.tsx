import React from 'react';
import { Search, Filter, X } from 'lucide-react';
import { WorkspaceFile, WorkspaceFolder, FileCategory, WorkspaceScope, PersonalUser } from '../types';
import { formatBytes } from '../utils/fileUtils';

interface StorageStatsBarProps {
  files: WorkspaceFile[];
  folders: WorkspaceFolder[];
  searchQuery: string;
  setSearchQuery: (val: string) => void;
  selectedCategory: FileCategory | 'all';
  setSelectedCategory: (cat: FileCategory | 'all') => void;
  onNewFolder: () => void;
  onDownloadAllAsZip: () => void;
  usedBytes: number;
  totalLimitBytes: number;
  workspaceScope: WorkspaceScope;
  personalUser: PersonalUser | null;
}

export const StorageStatsBar: React.FC<StorageStatsBarProps> = ({
  files,
  folders,
  searchQuery,
  setSearchQuery,
  selectedCategory,
  setSelectedCategory,
  usedBytes,
  workspaceScope,
}) => {
  const categories: { id: FileCategory | 'all'; label: string }[] = [
    { id: 'all', label: 'Todos' },
    { id: 'document', label: 'Documentos' },
    { id: 'image', label: 'Imagens' },
    { id: 'code', label: 'Códigos' },
    { id: 'archive', label: 'Compactados' },
  ];

  return (
    <div className="w-full space-y-2.5">
      {/* Ultra-Clean Search & Filter Dock */}
      <div className="crystal-squircle p-2.5 sm:p-3 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
        {/* Search Bar with large touch target */}
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
          <input
            id="workspace-search-input"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              workspaceScope === 'personal'
                ? 'Buscar no cofre pessoal (ex: .pdf, notas, contrato)...'
                : 'Buscar arquivos ou extensões (.png, .pdf, .md)...'
            }
            className="w-full pl-10 pr-9 py-2 text-xs sm:text-sm text-slate-800 bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 transition-all placeholder:text-slate-400 shadow-2xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
              title="Limpar busca"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 sm:pb-0 scrollbar-none">
          <Filter className="w-3.5 h-3.5 text-slate-400 mr-0.5 shrink-0 hidden lg:block" />
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-cyan-600 text-white font-semibold shadow-xs shadow-cyan-600/20'
                  : 'bg-slate-100/90 text-slate-600 hover:text-slate-900 hover:bg-slate-200/70 border border-slate-200/60'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Subtle, zen summary line (replaces cluttered metric blocks) */}
      <div className="px-1 flex items-center justify-between text-[11px] sm:text-xs text-slate-500">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-slate-700">
            {folders.length} {folders.length === 1 ? 'pasta' : 'pastas'}
          </span>
          <span>•</span>
          <span>
            {files.length} {files.length === 1 ? 'arquivo' : 'arquivos'}
          </span>
          <span>•</span>
          <span className="font-mono text-cyan-800 font-medium">{formatBytes(usedBytes)} em nuvem</span>
        </div>

        <span className="hidden sm:inline text-slate-400 text-[11px]">
          {workspaceScope === 'personal' ? '🔒 Cofre Privado' : '⚡ Sincronização Ativa'}
        </span>
      </div>
    </div>
  );
};
