import React from 'react';
import {
  X,
  Monitor,
  ShieldCheck,
  CheckCircle,
  Download,
  Code,
  Layers,
  Cpu,
  RefreshCw,
  Sparkles,
} from 'lucide-react';

interface IE11CompatibilityPanelProps {
  isOpen: boolean;
  onClose: () => void;
  isIE11Mode: boolean;
  setIsIE11Mode: (val: boolean) => void;
}

export const IE11CompatibilityPanel: React.FC<IE11CompatibilityPanelProps> = ({
  isOpen,
  onClose,
  isIE11Mode,
  setIsIE11Mode,
}) => {
  if (!isOpen) return null;

  const polyfills = [
    {
      title: 'Fallback de Download Legado (msSaveOrOpenBlob)',
      desc: 'No IE11 o atributo "download" do HTML5 não é suportado. O app intercepta e aciona window.navigator.msSaveOrOpenBlob(blob, filename) para downloads instantâneos sem erros.',
      status: 'Ativo & Pronto',
    },
    {
      title: 'Degradação Graciosa de Vidro Fosco (Backdrop-filter)',
      desc: 'Navegadores sem suporte a filtros de refração recebem automaticamente fundos sólidos calculados em RGBA/HEX de alto contraste (#ffffff / #f8fafc) com bordas sólidas.',
      status: 'Ativo & Pronto',
    },
    {
      title: 'Compatibilidade de Sincronização em Tempo Real',
      desc: 'Implementação de fallback em cascata: WebSocket com suporte a transporte seguro e reconexão automática com fallback para REST polling em caso de proxy corporativo legado.',
      status: 'Ativo & Pronto',
    },
    {
      title: 'Shims de ES5 / Object.assign / CustomEvent',
      desc: 'Garante que métodos modernos e manipuladores de eventos assíncronos funcionem sem quebra no motor Chakra/Trident 7 do Internet Explorer 11.',
      status: 'Ativo & Pronto',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        id="modal-ie11-compatibility"
        className="crystal-squircle w-full max-w-2xl bg-white/98 border border-amber-300 shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-amber-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 border border-amber-300 flex items-center justify-center text-amber-700">
              <Monitor className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                  Compatibilidade com Internet Explorer 11 & Legados
                </h3>
              </div>
              <p className="text-xs text-slate-500">
                Camada de compatibilidade progressiva e polyfills corporativos
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 sm:p-6 space-y-5">
          {/* Interactive Simulation Switch */}
          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-300 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-1">
              <p className="text-xs font-bold text-amber-950 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                Simulador de Renderização IE11 / Edge Legado
              </p>
              <p className="text-xs text-slate-700">
                Desativa efeitos translúcidos e aplica o tema sólido corporativo com propriedades estritas de compatibilidade.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setIsIE11Mode(!isIE11Mode)}
              className={`px-4 py-2 text-xs font-bold rounded-xl border transition-all shrink-0 cursor-pointer ${
                isIE11Mode
                  ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                  : 'bg-white text-slate-700 border-slate-300 hover:border-slate-400'
              }`}
            >
              {isIE11Mode ? 'Modo IE11 ATIVADO' : 'Ativar Simulação IE11'}
            </button>
          </div>

          {/* Polyfills Checklist */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Garantias de Compatibilidade Integradas
            </h4>

            <div className="space-y-2.5">
              {polyfills.map((p, idx) => (
                <div key={idx} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-start gap-3">
                  <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-xs font-bold text-slate-900">{p.title}</p>
                      <span className="text-[10px] font-mono font-bold text-emerald-800 bg-emerald-100 px-1.5 py-0.2 rounded border border-emerald-300">
                        {p.status}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">{p.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 sm:p-5 border-t border-slate-200 flex items-center justify-between bg-slate-50/80">
          <span className="text-xs text-slate-500 font-mono">
            Padrão W3C & Microsoft Trident 7.0 Ready
          </span>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
};
