import React, { useState } from 'react';
import {
  X,
  Users,
  Activity,
  UserPlus,
  Shield,
  Clock,
  Upload,
  RotateCcw,
  MessageSquare,
  Lock,
  Folder,
} from 'lucide-react';
import { TeamMember, ActivityEvent, WorkspaceFolder } from '../types';
import { formatTimeAgo } from '../utils/fileUtils';

interface TeamCollaborationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  members: TeamMember[];
  activities: ActivityEvent[];
  folders: WorkspaceFolder[];
  onAddMember: (name: string, email: string, role: TeamMember['role']) => void;
}

export const TeamCollaborationDrawer: React.FC<TeamCollaborationDrawerProps> = ({
  isOpen,
  onClose,
  members,
  activities,
  folders,
  onAddMember,
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'members' | 'activity'>('members');
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberEmail, setNewMemberEmail] = useState('');
  const [newMemberRole, setNewMemberRole] = useState<TeamMember['role']>('Editor');
  const [showAddForm, setShowAddForm] = useState(false);

  const handleCreateMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemberName.trim() || !newMemberEmail.trim()) return;
    onAddMember(newMemberName.trim(), newMemberEmail.trim(), newMemberRole);
    setNewMemberName('');
    setNewMemberEmail('');
    setShowAddForm(false);
  };

  const getEventIcon = (type: ActivityEvent['type']) => {
    switch (type) {
      case 'upload':
        return <Upload className="w-3.5 h-3.5 text-cyan-600" />;
      case 'version_revert':
        return <RotateCcw className="w-3.5 h-3.5 text-amber-600" />;
      case 'comment':
        return <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />;
      case 'lock':
      case 'unlock':
        return <Lock className="w-3.5 h-3.5 text-purple-600" />;
      case 'folder_create':
        return <Folder className="w-3.5 h-3.5 text-blue-600" />;
      default:
        return <Activity className="w-3.5 h-3.5 text-slate-500" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/30 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        id="drawer-team-collaboration"
        className="w-full max-w-md h-full bg-white border-l border-slate-200 p-5 flex flex-col justify-between shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div>
          <div className="flex items-center justify-between pb-4 border-b border-slate-200">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-cyan-100 border border-cyan-200 flex items-center justify-center text-cyan-700">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 tracking-tight">Colaboração em Equipe</h3>
                <p className="text-xs text-slate-500">Presença ao vivo e registro de atividades</p>
              </div>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Tab Selector */}
          <div className="grid grid-cols-2 gap-2 mt-4 p-1 rounded-xl bg-slate-100 border border-slate-200">
            <button
              type="button"
              onClick={() => setActiveTab('members')}
              className={`py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'members'
                  ? 'bg-white text-cyan-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Membros ({members.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('activity')}
              className={`py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'activity'
                  ? 'bg-white text-cyan-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Feed de Atividades
            </button>
          </div>

          {/* Tab Content */}
          <div className="mt-4 overflow-y-auto max-h-[calc(100vh-230px)] space-y-3 pr-1">
            {activeTab === 'members' ? (
              <>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    Equipe do Workspace
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowAddForm(!showAddForm)}
                    className="flex items-center gap-1 text-xs font-semibold text-cyan-700 hover:text-cyan-800 cursor-pointer"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>{showAddForm ? 'Cancelar' : 'Convidar'}</span>
                  </button>
                </div>

                {/* Add Member Form */}
                {showAddForm && (
                  <form onSubmit={handleCreateMember} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2.5">
                    <input
                      type="text"
                      value={newMemberName}
                      onChange={(e) => setNewMemberName(e.target.value)}
                      placeholder="Nome completo do colega..."
                      className="w-full text-xs p-2 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-cyan-500"
                      required
                    />
                    <input
                      type="email"
                      value={newMemberEmail}
                      onChange={(e) => setNewMemberEmail(e.target.value)}
                      placeholder="E-mail profissional..."
                      className="w-full text-xs p-2 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-none focus:border-cyan-500"
                      required
                    />
                    <div className="flex items-center justify-between gap-2">
                      <select
                        value={newMemberRole}
                        onChange={(e) => setNewMemberRole(e.target.value as TeamMember['role'])}
                        className="text-xs p-2 rounded-xl bg-white border border-slate-300 text-slate-800 flex-1"
                      >
                        <option value="Editor">Editor</option>
                        <option value="Admin">Admin</option>
                        <option value="Viewer">Visualizador</option>
                      </select>
                      <button
                        type="submit"
                        className="px-4 py-2 text-xs font-bold text-white bg-cyan-600 hover:bg-cyan-500 rounded-xl"
                      >
                        Adicionar
                      </button>
                    </div>
                  </form>
                )}

                {/* Member List */}
                <div className="space-y-2">
                  {members.map((m) => (
                    <div
                      key={m.id}
                      className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3 hover:border-slate-300 transition-colors"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="relative shrink-0">
                          <img src={m.avatar} alt={m.name} className="w-9 h-9 rounded-full object-cover ring-1 ring-slate-300" />
                          <span
                            className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full ring-2 ring-white ${
                              m.status === 'online'
                                ? 'bg-emerald-500'
                                : m.status === 'busy'
                                ? 'bg-amber-500'
                                : 'bg-slate-400'
                            }`}
                          />
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-slate-900 truncate">{m.name}</p>
                          <p className="text-[11px] text-slate-500 truncate">{m.email}</p>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-md font-semibold border ${
                            m.role === 'Admin'
                              ? 'bg-purple-50 text-purple-800 border-purple-200'
                              : m.role === 'Editor'
                              ? 'bg-cyan-50 text-cyan-800 border-cyan-200'
                              : 'bg-slate-100 text-slate-700 border-slate-200'
                          }`}
                        >
                          {m.role}
                        </span>
                        <p className="text-[9px] text-slate-400 mt-1 capitalize">{m.status}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              /* Activity Feed */
              <div className="space-y-2.5">
                {activities.map((act) => (
                  <div key={act.id} className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-lg bg-white border border-slate-200 flex items-center justify-center">
                          {getEventIcon(act.type)}
                        </div>
                        <span className="text-xs font-bold text-slate-800">{act.userName}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono">{formatTimeAgo(act.timestamp)}</span>
                    </div>
                    <p className="text-xs text-slate-600 pl-8 leading-snug">{act.details}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Drawer Footer */}
        <div className="pt-4 border-t border-slate-200 text-center">
          <p className="text-[11px] text-slate-500 flex items-center justify-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-cyan-600" />
            Sincronização em tempo real ativa no cluster
          </p>
        </div>
      </div>
    </div>
  );
};
