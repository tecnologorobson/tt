import React, { useState } from 'react';
import {
  X,
  Download,
  History,
  Lock,
  Unlock,
  MessageSquare,
  Send,
  Copy,
  Check,
  Edit3,
  Save,
  FileCode,
} from 'lucide-react';
import { WorkspaceFile, TeamMember } from '../types';
import { formatBytes, formatTimeAgo, downloadWorkspaceFile } from '../utils/fileUtils';

interface FilePreviewModalProps {
  file: WorkspaceFile | null;
  activeMember: TeamMember;
  onClose: () => void;
  onOpenVersions: (file: WorkspaceFile) => void;
  onToggleLock: (file: WorkspaceFile) => void;
  onAddComment: (fileId: string, content: string) => Promise<void>;
  onSaveContentRevision: (fileId: string, newContent: string, summary: string) => Promise<void>;
}

export const FilePreviewModal: React.FC<FilePreviewModalProps> = ({
  file,
  activeMember,
  onClose,
  onOpenVersions,
  onToggleLock,
  onAddComment,
  onSaveContentRevision,
}) => {
  if (!file) return null;

  // Helper to decode text content if stored as Data URL
  const getTextContent = (raw?: string): string => {
    if (!raw) return '';
    if (raw.startsWith('data:text/') || raw.startsWith('data:application/json')) {
      try {
        const parts = raw.split(',');
        if (parts[0].includes('base64')) {
          return atob(parts[1]);
        }
        return decodeURIComponent(parts[1]);
      } catch {
        return raw;
      }
    }
    return raw;
  };

  const [commentInput, setCommentInput] = useState('');
  const [isSendingComment, setIsSendingComment] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editBuffer, setEditBuffer] = useState(getTextContent(file.content));
  const [editSummary, setEditSummary] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const isImageFile =
    file.category === 'image' ||
    file.mimeType.startsWith('image/') ||
    (file.previewUrl && (file.previewUrl.startsWith('http') || file.previewUrl.startsWith('data:image/'))) ||
    (file.content && file.content.startsWith('data:image/'));

  const imageSrc = file.previewUrl || (file.content?.startsWith('data:image/') ? file.content : undefined);

  const handleDownload = async () => {
    try {
      await downloadWorkspaceFile(file);
    } catch {
      // fallback
    }
  };

  const handleCopy = () => {
    if (file.content) {
      navigator.clipboard.writeText(file.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleSendComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim()) return;
    setIsSendingComment(true);
    await onAddComment(file.id, commentInput.trim());
    setCommentInput('');
    setIsSendingComment(false);
  };

  const handleSaveEdit = async () => {
    setIsSaving(true);
    await onSaveContentRevision(
      file.id,
      editBuffer,
      editSummary || `Edição rápida no workspace (v${file.currentVersion + 1})`
    );
    setIsSaving(false);
    setIsEditing(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        id="modal-file-preview"
        className="crystal-squircle w-full max-w-5xl max-h-[92vh] flex flex-col bg-white/95 border border-slate-200 shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-cyan-100 border border-cyan-200 flex items-center justify-center text-cyan-700 shrink-0">
              <FileCode className="w-5 h-5" />
            </div>
            <div className="truncate">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-base font-bold text-slate-900 tracking-tight truncate">{file.name}</h3>
                <button
                  type="button"
                  onClick={() => onOpenVersions(file)}
                  className="px-2 py-0.5 text-xs font-mono font-bold rounded-md bg-cyan-100 text-cyan-900 border border-cyan-300 hover:bg-cyan-200 cursor-pointer"
                  title="Abrir histórico de versões"
                >
                  v{file.currentVersion}
                </button>
                {file.isLocked && (
                  <span className="px-2 py-0.5 text-[11px] rounded-md bg-amber-100 text-amber-900 border border-amber-300 font-medium">
                    Bloqueado por {file.lockedBy?.name || 'Membro'}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 font-mono">
                {formatBytes(file.sizeBytes)} • Atualizado {formatTimeAgo(file.updatedAt)} por{' '}
                {file.updatedBy?.name || file.createdBy?.name || 'Membro'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Lock / Unlock Toggle */}
            <button
              type="button"
              onClick={() => onToggleLock(file)}
              className={`p-2 rounded-xl border text-xs font-medium flex items-center gap-1 transition-all cursor-pointer ${
                file.isLocked
                  ? 'bg-amber-50 text-amber-900 border-amber-300'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
              title={file.isLocked ? 'Desbloquear edição colaborativa' : 'Bloquear edição para outros membros'}
            >
              {file.isLocked ? <Lock className="w-4 h-4 text-amber-600" /> : <Unlock className="w-4 h-4 text-slate-500" />}
              <span className="hidden sm:inline">{file.isLocked ? 'Bloqueado' : 'Livre'}</span>
            </button>

            {/* Versions trigger */}
            <button
              type="button"
              onClick={() => onOpenVersions(file)}
              className="p-2 rounded-xl text-slate-700 hover:text-cyan-800 bg-white hover:bg-slate-50 border border-slate-200 transition-all cursor-pointer"
              title="Histórico de versões"
            >
              <History className="w-4 h-4" />
            </button>

            {/* Download Trigger */}
            <button
              type="button"
              onClick={handleDownload}
              className="flex items-center gap-1 px-3.5 py-2 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 shadow-sm transition-all cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">Baixar</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Main Body: 2 Columns on desktop (Viewer + Comments) */}
        <div className="flex-1 overflow-hidden grid grid-cols-1 lg:grid-cols-3">
          {/* Main Viewer Area */}
          <div className="lg:col-span-2 flex flex-col border-b lg:border-b-0 lg:border-r border-slate-200 bg-slate-50/60 p-4 sm:p-5 overflow-y-auto">
            {/* Viewer Controls */}
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  {file.previewUrl ? 'Visualização de Mídia' : 'Prévia do Documento / Código'}
                </span>
              </div>

              <div className="flex items-center gap-2">
                {file.content && !file.previewUrl && (
                  <>
                    <button
                      type="button"
                      onClick={handleCopy}
                      className="flex items-center gap-1 px-2.5 py-1 text-xs rounded-lg bg-white border border-slate-200 text-slate-700 hover:bg-slate-100"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copied ? 'Copiado' : 'Copiar'}</span>
                    </button>

                    {!file.isLocked || file.lockedBy?.id === activeMember.id ? (
                      <button
                        type="button"
                        onClick={() => setIsEditing(!isEditing)}
                        className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded-lg border transition-all ${
                          isEditing
                            ? 'bg-amber-100 text-amber-900 border-amber-300'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>{isEditing ? 'Cancelar Edição' : 'Editar'}</span>
                      </button>
                    ) : null}
                  </>
                )}
              </div>
            </div>

            {/* Display Body */}
            <div className="flex-1 flex flex-col justify-center">
              {imageSrc ? (
                <div className="flex items-center justify-center p-2 rounded-2xl bg-white border border-slate-200 overflow-hidden max-h-[500px]">
                  <img
                    src={imageSrc}
                    alt={file.name}
                    className="max-h-[460px] w-auto object-contain rounded-xl shadow-xs"
                  />
                </div>
              ) : isEditing ? (
                <div className="space-y-3">
                  <textarea
                    value={editBuffer}
                    onChange={(e) => setEditBuffer(e.target.value)}
                    rows={14}
                    className="w-full text-xs font-mono p-3 bg-slate-900 text-slate-100 border border-slate-700 rounded-2xl focus:outline-none focus:border-cyan-500 leading-relaxed"
                  />
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                    <input
                      type="text"
                      value={editSummary}
                      onChange={(e) => setEditSummary(e.target.value)}
                      placeholder="Resumo da alteração (para versionamento automático)..."
                      className="flex-1 text-xs bg-white border border-slate-300 text-slate-800 rounded-xl px-3 py-2 focus:outline-none focus:border-cyan-500"
                    />
                    <button
                      type="button"
                      onClick={handleSaveEdit}
                      disabled={isSaving}
                      className="flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-emerald-600 to-teal-600 rounded-xl shadow-xs"
                    >
                      <Save className="w-4 h-4" />
                      <span>{isSaving ? 'Salvando v' + (file.currentVersion + 1) : 'Salvar Revisão'}</span>
                    </button>
                  </div>
                </div>
              ) : file.content ? (
                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-700 text-xs font-mono text-slate-200 overflow-auto max-h-[460px] leading-relaxed">
                  <pre>{getTextContent(file.content)}</pre>
                </div>
              ) : (
                <div className="p-8 rounded-2xl border border-dashed border-slate-300 bg-white text-center space-y-2">
                  <p className="text-xs text-slate-600 font-semibold">Pré-visualização direta não disponível</p>
                  <p className="text-xs text-slate-500">Faça o download do arquivo para abrir no software apropriado.</p>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Collaboration Comments & Audit Feed */}
          <div className="flex flex-col bg-white p-4 sm:p-5">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-cyan-600" />
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Comentários ({file.comments.length})
                </h4>
              </div>
            </div>

            {/* Comments List */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-1 max-h-[350px]">
              {file.comments.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-400">
                  Nenhum comentário registrado ainda. Envie o primeiro feedback da equipe!
                </div>
              ) : (
                file.comments.map((c) => (
                  <div key={c.id} className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <img src={c.author.avatar} alt={c.author.name} className="w-4 h-4 rounded-full object-cover" />
                        <span className="text-xs font-bold text-slate-900">{c.author.name}</span>
                      </div>
                      <span className="text-[10px] text-slate-400">{formatTimeAgo(c.createdAt)}</span>
                    </div>
                    <p className="text-xs text-slate-700 pl-5.5 leading-relaxed">{c.content}</p>
                  </div>
                ))
              )}
            </div>

            {/* Post Comment Input */}
            <form onSubmit={handleSendComment} className="pt-3 mt-3 border-t border-slate-200 flex gap-2">
              <input
                type="text"
                value={commentInput}
                onChange={(e) => setCommentInput(e.target.value)}
                placeholder="Escreva um comentário sobre este arquivo..."
                className="flex-1 text-xs bg-slate-50 border border-slate-300 text-slate-850 rounded-xl px-3 py-2 focus:outline-none focus:border-cyan-500 focus:bg-white"
              />
              <button
                type="submit"
                disabled={isSendingComment || !commentInput.trim()}
                className="p-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white disabled:opacity-40 transition-colors cursor-pointer"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
