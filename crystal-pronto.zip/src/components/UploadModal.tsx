import React, { useState, useRef } from 'react';
import {
  X,
  Upload,
  File,
  CheckCircle,
  AlertTriangle,
  Folder,
  Layers,
  FileText,
  Clock,
  ArrowRight,
} from 'lucide-react';
import { WorkspaceFolder, WorkspaceFile } from '../types';
import { formatBytes } from '../utils/fileUtils';

interface UploadModalProps {
  folders: WorkspaceFolder[];
  files: WorkspaceFile[];
  initialFolderId?: string;
  onClose: () => void;
  onUploadBatch: (
    items: {
      folderId: string;
      name: string;
      sizeBytes: number;
      mimeType: string;
      content?: string;
      previewUrl?: string;
      changeSummary?: string;
    }[]
  ) => Promise<void>;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  folders,
  files,
  initialFolderId,
  onClose,
  onUploadBatch,
}) => {
  const [selectedFolderId, setSelectedFolderId] = useState<string>(initialFolderId || folders[0]?.id || 'folder-1');
  const [queuedFiles, setQueuedFiles] = useState<
    {
      file: File;
      name: string;
      size: number;
      type: string;
      changeSummary: string;
      isDuplicateName: boolean;
      existingFileVersion?: number;
      previewUrl?: string;
      content?: string;
    }[]
  >([]);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [uploadSpeed] = useState<string>('24.5 MB/s');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFiles = async (fileList: FileList) => {
    const chosenFolderFiles = files.filter((f) => f.folderId === selectedFolderId);

    const filePromises = Array.from(fileList).map(async (f) => {
      const existing = chosenFolderFiles.find((ef) => ef.name.toLowerCase() === f.name.toLowerCase());
      const isDuplicate = !!existing;

      // Read file as Data URL to guarantee 100% binary and text preservation without corruption
      const dataUrl = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve((e.target?.result as string) || '');
        reader.onerror = () => resolve('');
        reader.readAsDataURL(f);
      });

      // Also read text files as plain text for markdown/code preview in editor
      let textContent: string | undefined = undefined;
      if (f.type.startsWith('text/') || f.name.match(/\.(md|json|js|ts|tsx|css|html|txt|py|sh|sql|xml|csv)$/i)) {
        try {
          textContent = await new Promise<string>((resolve) => {
            const txtReader = new FileReader();
            txtReader.onload = (e) => resolve((e.target?.result as string) || '');
            txtReader.onerror = () => resolve('');
            txtReader.readAsText(f);
          });
        } catch {
          // ignore
        }
      }

      return {
        file: f,
        name: f.name,
        size: f.size,
        type: f.type || 'application/octet-stream',
        changeSummary: isDuplicate
          ? `Atualização automática para a revisão v${(existing?.currentVersion || 1) + 1}.`
          : 'Upload inicial do arquivo no workspace.',
        isDuplicateName: isDuplicate,
        existingFileVersion: existing?.currentVersion,
        previewUrl: f.type.startsWith('image/') ? dataUrl : undefined,
        content: dataUrl || textContent, // Data URL preserves exact binary bits
      };
    });

    const newItems = await Promise.all(filePromises);
    setQueuedFiles((prev) => [...prev, ...newItems]);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(e.dataTransfer.files);
    }
  };

  const handleRemoveItem = (index: number) => {
    setQueuedFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async () => {
    if (queuedFiles.length === 0) return;
    setIsUploading(true);
    setUploadProgress(15);

    const interval = setInterval(() => {
      setUploadProgress((p) => {
        if (p >= 95) {
          clearInterval(interval);
          return 95;
        }
        return p + 20;
      });
    }, 120);

    const payload = queuedFiles.map((q) => ({
      folderId: selectedFolderId,
      name: q.name,
      sizeBytes: q.size,
      mimeType: q.type,
      content: q.content,
      previewUrl: q.previewUrl,
      changeSummary: q.changeSummary,
    }));

    try {
      await onUploadBatch(payload);
      setUploadProgress(100);
      setTimeout(() => {
        clearInterval(interval);
        setIsUploading(false);
        onClose();
      }, 400);
    } catch {
      clearInterval(interval);
      setIsUploading(false);
      alert('Erro durante a transmissão para a nuvem.');
    }
  };

  const currentFolder = folders.find((f) => f.id === selectedFolderId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        id="modal-file-upload-hub"
        className="crystal-squircle w-full max-w-3xl max-h-[90vh] flex flex-col bg-white/95 border border-slate-200 shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-200 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-100 border border-cyan-200 flex items-center justify-center text-cyan-700">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                Central de Upload & Sincronização
              </h3>
              <p className="text-xs text-slate-500">
                Suporte a múltiplos arquivos, arraste-e-solte e versionamento automático de revisões
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5">
          {/* Destination Folder Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Pasta de Destino no Workspace:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {folders.map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setSelectedFolderId(f.id)}
                  className={`p-3 rounded-2xl border text-left transition-all flex items-center gap-3 cursor-pointer ${
                    selectedFolderId === f.id
                      ? 'bg-cyan-50 border-cyan-400 text-cyan-950 ring-1 ring-cyan-400/40 shadow-xs'
                      : 'bg-slate-50/70 border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-white'
                  }`}
                >
                  <div className="w-8 h-8 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-cyan-700">
                    <Folder className="w-4 h-4" />
                  </div>
                  <div className="truncate">
                    <p className="text-xs font-semibold truncate text-slate-900">{f.name}</p>
                    <p className="text-[11px] text-slate-500 truncate">{f.description || 'Pasta organizada'}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Drag & Drop Area */}
          <div
            onDragOver={handleDragOver}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className="py-8 px-6 rounded-3xl border-2 border-dashed border-cyan-400 bg-cyan-50/40 hover:bg-cyan-50/70 hover:border-cyan-500 transition-all text-center cursor-pointer group"
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              className="hidden"
              onChange={(e) => {
                if (e.target.files && e.target.files.length > 0) {
                  processFiles(e.target.files);
                }
              }}
            />
            <div className="w-12 h-12 mx-auto rounded-2xl bg-white border border-cyan-200 shadow-2xs flex items-center justify-center text-cyan-700 group-hover:scale-110 transition-transform">
              <Upload className="w-6 h-6 animate-bounce" />
            </div>
            <p className="mt-3 text-sm font-bold text-slate-900">
              Arraste seus arquivos para cá ou <span className="text-cyan-700 underline">clique para procurar</span>
            </p>
            <p className="mt-1 text-xs text-slate-500">
              Imagens, Documentos, Código, Áudio, Vídeo ou ZIPs (sem limite de tamanho para demonstração)
            </p>
          </div>

          {/* Queued Files List */}
          {queuedFiles.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Fila de Envio ({queuedFiles.length})
                </span>
                <span className="text-xs font-mono text-slate-500">
                  Total: {formatBytes(queuedFiles.reduce((sum, q) => sum + q.size, 0))}
                </span>
              </div>

              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {queuedFiles.map((q, idx) => (
                  <div
                    key={idx}
                    className={`p-3 rounded-2xl border transition-all ${
                      q.isDuplicateName
                        ? 'bg-amber-50/60 border-amber-300'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5 min-w-0">
                        {q.previewUrl ? (
                          <img
                            src={q.previewUrl}
                            alt={q.name}
                            className="w-10 h-10 rounded-xl object-cover border border-slate-200 shrink-0"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-cyan-700 shrink-0">
                            <File className="w-5 h-5" />
                          </div>
                        )}
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-slate-900 truncate">{q.name}</p>
                          <p className="text-[11px] text-slate-500 font-mono">{formatBytes(q.size)}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {q.isDuplicateName && (
                          <span className="flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 border border-amber-300">
                            <Layers className="w-3 h-3 text-amber-700" />
                            <span>Nova Versão v{(q.existingFileVersion || 1) + 1}</span>
                          </span>
                        )}
                        <button
                          type="button"
                          onClick={() => handleRemoveItem(idx)}
                          className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Change summary input */}
                    <div className="mt-2 pt-2 border-t border-slate-200/80 flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <input
                        type="text"
                        value={q.changeSummary}
                        onChange={(e) => {
                          const val = e.target.value;
                          setQueuedFiles((prev) =>
                            prev.map((item, i) => (i === idx ? { ...item, changeSummary: val } : item))
                          );
                        }}
                        placeholder="Nota de versão / Resumo das alterações..."
                        className="w-full text-[11px] bg-white border border-slate-200 rounded-lg px-2 py-1 text-slate-800 placeholder:text-slate-400 focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Upload Progress Bar */}
          {isUploading && (
            <div className="p-4 rounded-2xl bg-cyan-50 border border-cyan-200 space-y-2 animate-in fade-in">
              <div className="flex items-center justify-between text-xs font-bold text-cyan-900">
                <span className="flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-cyan-600 animate-spin" />
                  Sincronizando com os clusters na nuvem...
                </span>
                <span className="font-mono">{uploadProgress}%</span>
              </div>
              <div className="w-full h-2 rounded-full bg-slate-200 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-cyan-600 to-blue-600 rounded-full transition-all duration-200"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] text-slate-500 font-mono">
                <span>Taxa: {uploadSpeed}</span>
                <span>Latência: 14ms (P2P Cluster)</span>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-5 border-t border-slate-200 flex items-center justify-between bg-slate-50/80">
          <div className="text-xs text-slate-500 hidden sm:block">
            Destino: <span className="font-semibold text-slate-800">{currentFolder?.name || 'Workspace'}</span>
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={onClose}
              disabled={isUploading}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 rounded-xl transition-all cursor-pointer"
            >
              Cancelar
            </button>

            <button
              id="btn-confirm-upload-batch"
              type="button"
              onClick={handleSubmit}
              disabled={queuedFiles.length === 0 || isUploading}
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 shadow-sm disabled:opacity-50 transition-all cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>
                {isUploading
                  ? 'Transmitindo...'
                  : queuedFiles.length > 0
                  ? `Fazer Upload (${queuedFiles.length})`
                  : 'Selecione Arquivos'}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
