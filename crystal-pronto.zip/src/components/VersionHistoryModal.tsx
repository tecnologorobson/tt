import React, { useState } from 'react';
import {
  X,
  History,
  RotateCcw,
  Download,
  GitCompare,
  FileCode,
  ShieldCheck,
  Calendar,
  User,
  Plus,
  Save,
} from 'lucide-react';
import { WorkspaceFile, FileVersion } from '../types';
import { formatBytes, formatTimeAgo, downloadWorkspaceFile } from '../utils/fileUtils';

interface VersionHistoryModalProps {
  file: WorkspaceFile | null;
  onClose: () => void;
  onRevertVersion: (fileId: string, versionNumber: number) => Promise<void>;
  onSaveNewRevision: (fileId: string, newContent: string, summary: string) => Promise<void>;
}

export const VersionHistoryModal: React.FC<VersionHistoryModalProps> = ({
  file,
  onClose,
  onRevertVersion,
  onSaveNewRevision,
}) => {
  if (!file) return null;

  const [selectedVersionNum, setSelectedVersionNum] = useState<number>(file.currentVersion);
  const [compareVersionNum, setCompareVersionNum] = useState<number | null>(
    file.versions.length > 1 ? file.versions[file.versions.length - 2].versionNumber : null
  );
  const [isDiffMode, setIsDiffMode] = useState<boolean>(false);
  const [isEditorMode, setIsEditorMode] = useState<boolean>(false);
  const [editorContent, setEditorContent] = useState<string>(file.content || '');
  const [revisionSummary, setRevisionSummary] = useState<string>('');
  const [isReverting, setIsReverting] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);

  const selectedVersion =
    file.versions.find((v) => v.versionNumber === selectedVersionNum) || file.versions[file.versions.length - 1];

  const compareVersion = compareVersionNum
    ? file.versions.find((v) => v.versionNumber === compareVersionNum)
    : null;

  const handleRevert = async (verNum: number) => {
    if (
      confirm(
        `Tem certeza que deseja restaurar a versão v${verNum}? O CrystalCloud criará automaticamente uma nova versão auditada (v${
          file.currentVersion + 1
        }) mantendo todo o histórico intacto.`
      )
    ) {
      setIsReverting(true);
      await onRevertVersion(file.id, verNum);
      setIsReverting(false);
      onClose();
    }
  };

  const handleSaveRevision = async () => {
    if (!revisionSummary.trim()) {
      alert('Por favor, informe um resumo das alterações desta nova revisão.');
      return;
    }
    setIsSaving(true);
    await onSaveNewRevision(file.id, editorContent, revisionSummary.trim());
    setIsSaving(false);
    setIsEditorMode(false);
  };

  const handleDownloadVersion = async (v: FileVersion) => {
    try {
      await downloadWorkspaceFile(file, v.versionNumber);
    } catch {
      // fallback
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        id="modal-version-history"
        className="crystal-squircle w-full max-w-4xl max-h-[90vh] flex flex-col bg-white/95 border border-slate-200 shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-200 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-100 border border-cyan-200 flex items-center justify-center text-cyan-700">
              <History className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">{file.name}</h3>
                <span className="px-2.5 py-0.5 text-xs font-bold rounded-full bg-cyan-100 text-cyan-900 border border-cyan-300">
                  v{file.currentVersion} Ativa
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Sistema de Versionamento Automático e Histórico de Revisões Imutáveis
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toolbar Subheader */}
        <div className="px-5 sm:px-6 py-2.5 bg-slate-100/70 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setIsEditorMode(false);
                setIsDiffMode(false);
              }}
              className={`px-3 py-1.5 rounded-xl font-medium transition-all ${
                !isEditorMode && !isDiffMode
                  ? 'bg-white text-cyan-900 border border-cyan-300 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
              }`}
            >
              Linha do Tempo
            </button>

            <button
              type="button"
              onClick={() => {
                setIsEditorMode(false);
                setIsDiffMode(true);
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
                isDiffMode
                  ? 'bg-white text-cyan-900 border border-cyan-300 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
              }`}
            >
              <GitCompare className="w-3.5 h-3.5" />
              <span>Comparar Revisões (Diff)</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setIsDiffMode(false);
                setIsEditorMode(true);
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
                isEditorMode
                  ? 'bg-white text-emerald-900 border border-emerald-300 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
              }`}
            >
              <Plus className="w-3.5 h-3.5 text-emerald-600" />
              <span>Nova Revisão Manual</span>
            </button>
          </div>

          <div className="flex items-center gap-2 text-slate-500 font-mono text-[11px]">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>SHA-256 Verificado</span>
          </div>
        </div>

        {/* Modal Main Content */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6">
          {isEditorMode ? (
            /* New Revision Editor */
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200">
                <h4 className="text-xs font-bold text-emerald-900 mb-1">Criar Versão v{file.currentVersion + 1}</h4>
                <p className="text-xs text-emerald-800">
                  Ao salvar, a revisão atual será arquivada e uma nova versão imutável será registrada em tempo real.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Resumo das Modificações *
                </label>
                <input
                  type="text"
                  value={revisionSummary}
                  onChange={(e) => setRevisionSummary(e.target.value)}
                  placeholder="Ex: Ajustes nos parâmetros de renderização, remoção de bugs..."
                  className="w-full text-xs p-2.5 rounded-xl bg-white border border-slate-300 text-slate-850 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Conteúdo do Arquivo
                </label>
                <textarea
                  value={editorContent}
                  onChange={(e) => setEditorContent(e.target.value)}
                  rows={10}
                  className="w-full text-xs p-3 font-mono rounded-xl bg-slate-900 text-slate-100 border border-slate-700 focus:outline-none focus:border-emerald-500 leading-relaxed"
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditorMode(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-100 rounded-xl"
                >
                  Voltar
                </button>
                <button
                  type="button"
                  onClick={handleSaveRevision}
                  disabled={isSaving || !revisionSummary.trim()}
                  className="flex items-center gap-1.5 px-5 py-2 text-xs font-semibold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 rounded-xl shadow-xs disabled:opacity-50"
                >
                  <Save className="w-4 h-4" />
                  <span>{isSaving ? 'Gravando Revisão...' : 'Gravar Nova Versão'}</span>
                </button>
              </div>
            </div>
          ) : isDiffMode ? (
            /* Diff Comparison View */
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">Versão Base:</label>
                  <select
                    value={compareVersionNum || ''}
                    onChange={(e) => setCompareVersionNum(Number(e.target.value))}
                    className="w-full p-2 text-xs rounded-xl bg-white border border-slate-300 text-slate-800"
                  >
                    {file.versions.map((v) => {
                      const verAuthor = v.uploadedBy?.name || v.createdBy?.name || 'Membro';
                      const verTime = v.uploadedAt || v.createdAt || file.createdAt;
                      return (
                        <option key={v.versionNumber} value={v.versionNumber}>
                          v{v.versionNumber} ({formatTimeAgo(verTime)}) - {verAuthor}
                        </option>
                      );
                    })}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">Versão Comparada:</label>
                  <select
                    value={selectedVersionNum}
                    onChange={(e) => setSelectedVersionNum(Number(e.target.value))}
                    className="w-full p-2 text-xs rounded-xl bg-white border border-slate-300 text-slate-800"
                  >
                    {file.versions.map((v) => {
                      const verAuthor = v.uploadedBy?.name || v.createdBy?.name || 'Membro';
                      const verTime = v.uploadedAt || v.createdAt || file.createdAt;
                      return (
                        <option key={v.versionNumber} value={v.versionNumber}>
                          v{v.versionNumber} ({formatTimeAgo(verTime)}) - {verAuthor}
                        </option>
                      );
                    })}
                  </select>
                </div>
              </div>

              {/* Diff Output Box */}
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-700 text-xs font-mono space-y-2">
                <div className="text-slate-400 pb-2 border-b border-slate-800 flex justify-between">
                  <span>--- v{compareVersion?.versionNumber || 1} ({compareVersion?.changeSummary})</span>
                  <span>+++ v{selectedVersion.versionNumber} ({selectedVersion.changeSummary})</span>
                </div>

                <div className="text-rose-400 bg-rose-950/40 p-2 rounded-lg border border-rose-800/40">
                  <p className="text-[10px] uppercase font-bold text-rose-300 mb-1">Linhas Anteriores (v{compareVersion?.versionNumber}):</p>
                  <p className="whitespace-pre-wrap">{compareVersion?.contentSnippet || 'Sem snippet disponível para esta versão antiga.'}</p>
                </div>

                <div className="text-emerald-400 bg-emerald-950/40 p-2 rounded-lg border border-emerald-800/40">
                  <p className="text-[10px] uppercase font-bold text-emerald-300 mb-1">Linhas Atualizadas (v{selectedVersion.versionNumber}):</p>
                  <p className="whitespace-pre-wrap">{selectedVersion.contentSnippet || file.content || 'Versão ativa corrente.'}</p>
                </div>
              </div>
            </div>
          ) : (
            /* Timeline & Version Cards */
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {/* Left Column: Version History Tree */}
              <div className="md:col-span-1 space-y-2.5 border-r border-slate-200 pr-0 md:pr-4">
                <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                  Histórico de Versões ({file.versions.length})
                </p>

                {[...file.versions].reverse().map((ver) => {
                  const isSelected = selectedVersionNum === ver.versionNumber;
                  const isCurrent = file.currentVersion === ver.versionNumber;

                  return (
                    <button
                      key={ver.versionNumber}
                      type="button"
                      onClick={() => setSelectedVersionNum(ver.versionNumber)}
                      className={`w-full p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-cyan-50 border-cyan-400 text-slate-900 ring-1 ring-cyan-400/40 shadow-xs'
                          : 'bg-slate-50/80 border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-mono text-xs font-bold text-cyan-800">
                          v{ver.versionNumber}
                        </span>
                        {isCurrent && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-emerald-100 text-emerald-800 font-bold border border-emerald-300">
                            Atual
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-slate-800 font-medium line-clamp-1">{ver.changeSummary}</p>

                      <div className="flex items-center justify-between text-[10px] text-slate-500 mt-2 font-mono">
                        <span className="truncate max-w-[80px]">{ver.uploadedBy?.name || ver.createdBy?.name || 'Membro'}</span>
                        <span>{formatTimeAgo(ver.uploadedAt || ver.createdAt || file.createdAt)}</span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Right Column: Selected Version Details */}
              <div className="md:col-span-2 space-y-4">
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-slate-900">Revisão v{selectedVersion.versionNumber}</h4>
                      <span className="text-xs font-mono text-slate-500">{formatBytes(selectedVersion.sizeBytes)}</span>
                    </div>
                    <p className="text-xs text-slate-600 mt-0.5">{selectedVersion.changeSummary}</p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleDownloadVersion(selectedVersion)}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-medium text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 shadow-2xs"
                      title="Download desta versão específica"
                    >
                      <Download className="w-3.5 h-3.5 text-cyan-600" />
                      <span>Baixar v{selectedVersion.versionNumber}</span>
                    </button>

                    {selectedVersion.versionNumber !== file.currentVersion && (
                      <button
                        type="button"
                        onClick={() => handleRevert(selectedVersion.versionNumber)}
                        disabled={isReverting}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold text-white bg-amber-600 hover:bg-amber-500 shadow-2xs"
                        title="Restaurar esta versão como a nova atual"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Restaurar</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Audit & Metadata Details */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                    <span className="text-[10px] text-slate-400 block">Autor da Revisão</span>
                    <span className="font-semibold text-slate-800 truncate block">
                      {selectedVersion.uploadedBy?.name || selectedVersion.createdBy?.name || 'Membro'}
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                    <span className="text-[10px] text-slate-400 block">Data de Gravação</span>
                    <span className="font-semibold text-slate-800 block">
                      {new Date(selectedVersion.uploadedAt || selectedVersion.createdAt || file.createdAt).toLocaleDateString('pt-BR')}
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                    <span className="text-[10px] text-slate-400 block">Hash de Integridade</span>
                    <span className="font-mono text-cyan-800 text-[10px] block truncate">
                      {selectedVersion.hashChecksum || selectedVersion.checksum || 'sha256:crystal...'}
                    </span>
                  </div>
                </div>

                {/* Code / Content Snapshot Preview */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      Snapshot do Conteúdo Registrado
                    </span>
                  </div>
                  <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-700 text-xs font-mono text-slate-200 overflow-x-auto max-h-60 leading-relaxed">
                    <pre>{selectedVersion.contentSnippet || file.content || `[Conteúdo binário de ${file.name}]`}</pre>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-5 border-t border-slate-200 flex items-center justify-between bg-slate-50/80">
          <div className="text-xs text-slate-500">
            Total de revisões auditadas na nuvem: <span className="font-bold text-slate-800">{file.versions.length}</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 text-xs font-medium text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl"
          >
            Fechar Histórico
          </button>
        </div>
      </div>
    </div>
  );
};
