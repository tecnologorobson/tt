import React, { useState, useRef } from 'react';
import {
  X,
  HardDrive,
  Trash2,
  RotateCcw,
  DownloadCloud,
  Shield,
  Layers,
  Monitor,
  Cloud,
  CloudOff,
  RefreshCw,
  CheckCircle,
  UserPlus,
  Image as ImageIcon,
  ZoomIn,
  Sliders,
  Upload,
} from 'lucide-react';
import {
  WorkspaceData,
  WorkspaceScope,
  PersonalUser,
  TeamMember,
  WorkspaceFolder,
  WorkspaceFile,
} from '../types';
import { formatBytes } from '../utils/fileUtils';
import { BackgroundSettings, compressBackgroundImage } from '../utils/imageOptimizer';

interface InfoHubModalProps {
  isOpen: boolean;
  onClose: () => void;
  workspaceScope: WorkspaceScope;
  setWorkspaceScope: (scope: WorkspaceScope) => void;
  personalUser: PersonalUser | null;
  onOpenAuthModal: () => void;
  onLogoutPersonal: () => void;
  teamData: WorkspaceData;
  personalFolders: WorkspaceFolder[];
  personalFiles: WorkspaceFile[];
  personalStorageUsed: number;
  personalStorageLimit: number;
  activeMember: TeamMember;
  onSelectMember: (m: TeamMember) => void;
  onOpenTeam: () => void;
  onOpenIE11Modal: () => void;
  onDownloadAllAsZip: () => void;
  onClearSamples: () => Promise<void>;
  onRestoreSamples: () => Promise<void>;
  isIE11Mode: boolean;
  onForceSync: () => void;
  bgSettings: BackgroundSettings;
  onUpdateBgSettings: (settings: BackgroundSettings) => void;
}

export const InfoHubModal: React.FC<InfoHubModalProps> = ({
  isOpen,
  onClose,
  workspaceScope,
  setWorkspaceScope,
  personalUser,
  onOpenAuthModal,
  onLogoutPersonal,
  teamData,
  personalFolders,
  personalFiles,
  personalStorageUsed,
  personalStorageLimit,
  activeMember,
  onSelectMember,
  onOpenTeam,
  onOpenIE11Modal,
  onDownloadAllAsZip,
  onClearSamples,
  onRestoreSamples,
  isIE11Mode,
  onForceSync,
  bgSettings,
  onUpdateBgSettings,
}) => {
  const [isClearing, setIsClearing] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [isCompressingBg, setIsCompressingBg] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);
  const bgFileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const currentFiles = workspaceScope === 'personal' ? personalFiles : teamData.files;
  const currentFolders = workspaceScope === 'personal' ? personalFolders : teamData.folders;
  const currentUsedBytes =
    workspaceScope === 'personal' ? personalStorageUsed : teamData.syncState.cloudStorageUsedBytes;
  const currentLimitBytes =
    workspaceScope === 'personal' ? personalStorageLimit : teamData.syncState.cloudStorageLimitBytes;

  const percentage = Math.min(100, Math.max(1, (currentUsedBytes / currentLimitBytes) * 100));

  const currentUserAvatar =
    workspaceScope === 'personal' && personalUser
      ? personalUser.avatar
      : activeMember?.avatar ||
        'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80';

  const currentUserName =
    workspaceScope === 'personal' && personalUser
      ? personalUser.name
      : activeMember?.name || 'Administrador';

  const connectionDotColor =
    teamData.syncState.status === 'synced'
      ? 'bg-emerald-500 ring-2 ring-white'
      : teamData.syncState.status === 'syncing'
      ? 'bg-amber-400 ring-2 ring-white'
      : 'bg-rose-500 ring-2 ring-white';

  const handleClear = async () => {
    if (!window.confirm('Deseja remover todas as amostras e usuários fictícios para começar com um espaço 100% limpo?')) {
      return;
    }
    setIsClearing(true);
    try {
      await onClearSamples();
      setFeedbackMsg('Workspace limpo! Todas as amostras e perfis fictícios foram removidos.');
      setTimeout(() => setFeedbackMsg(null), 4000);
    } catch {
      setFeedbackMsg('Erro ao limpar amostras.');
    } finally {
      setIsClearing(false);
    }
  };

  const handleRestore = async () => {
    setIsRestoring(true);
    try {
      await onRestoreSamples();
      setFeedbackMsg('Amostras de demonstração restauradas.');
      setTimeout(() => setFeedbackMsg(null), 4000);
    } catch {
      setFeedbackMsg('Erro ao restaurar amostras.');
    } finally {
      setIsRestoring(false);
    }
  };

  const handleBgFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsCompressingBg(true);
    try {
      // Compress automatically if heavy to max 1 Megabyte (1MB)
      const compressedDataUrl = await compressBackgroundImage(file, 1024 * 1024);
      onUpdateBgSettings({
        ...bgSettings,
        imageUrl: compressedDataUrl,
      });
      setFeedbackMsg('Plano de fundo aplicado e otimizado com sucesso!');
      setTimeout(() => setFeedbackMsg(null), 3000);
    } catch (err) {
      console.error('Erro ao processar imagem de fundo:', err);
      setFeedbackMsg('Falha ao processar a imagem de fundo.');
    } finally {
      setIsCompressingBg(false);
      if (bgFileInputRef.current) {
        bgFileInputRef.current.value = '';
      }
    }
  };

  const presetWallpapers = [
    {
      name: 'Aurora Minimal',
      url: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1600&auto=format&fit=crop&q=80',
    },
    {
      name: 'Crystal Geometria',
      url: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?w=1600&auto=format&fit=crop&q=80',
    },
    {
      name: 'Montanha Pastel',
      url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=1600&auto=format&fit=crop&q=80',
    },
    {
      name: 'Nuvens Suaves',
      url: 'https://images.unsplash.com/photo-1534088568595-a066f410bcda?w=1600&auto=format&fit=crop&q=80',
    },
  ];

  return (
    <div
      id="modal-info-hub-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="modal-info-hub"
        className="crystal-squircle w-full max-w-lg bg-white/95 border border-white/80 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header with User Avatar and Solid Connection Dot */}
        <div className="p-4 sm:p-5 border-b border-slate-200/80 flex items-center justify-between bg-white/60 shrink-0">
          <div className="flex items-center gap-3">
            <div className="relative flex items-center justify-center w-11 h-11 rounded-2xl p-0.5 bg-gradient-to-tr from-cyan-600 to-blue-600 shadow-md shadow-cyan-600/20 shrink-0">
              <img
                src={currentUserAvatar}
                alt={currentUserName}
                className="w-full h-full rounded-[14px] object-cover bg-white"
              />
              <span className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full ${connectionDotColor}`} />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
                Painel CrystalCloud
              </h3>
              <p className="text-xs text-slate-500">
                {currentUserName} • Armazenamento, Fundo e Opções
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
          {/* Feedback Message */}
          {feedbackMsg && (
            <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{feedbackMsg}</span>
            </div>
          )}

          {/* Section 1: Storage & Cloud Sync Status */}
          <div className="p-4 rounded-2xl bg-white/80 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-cyan-700" />
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  {workspaceScope === 'personal' ? 'Cofre Pessoal' : 'Espaço em Nuvem'}
                </span>
              </div>
              <button
                type="button"
                onClick={onForceSync}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-white border border-slate-200 text-[11px] font-semibold text-slate-700 hover:text-cyan-800 hover:border-cyan-400 transition-all cursor-pointer shadow-2xs"
              >
                {teamData.syncState.status === 'synced' ? (
                  <>
                    <Cloud className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Conectado ({teamData.syncState.latencyMs}ms)</span>
                  </>
                ) : teamData.syncState.status === 'syncing' ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 text-cyan-600 animate-spin" />
                    <span>Sincronizando...</span>
                  </>
                ) : (
                  <>
                    <CloudOff className="w-3.5 h-3.5 text-rose-500" />
                    <span>Reconectar</span>
                  </>
                )}
              </button>
            </div>

            {/* Storage bar */}
            <div>
              <div className="flex justify-between items-center text-xs mb-1.5">
                <span className="text-slate-600 font-medium">
                  {formatBytes(currentUsedBytes)} usados de {formatBytes(currentLimitBytes)}
                </span>
                <span className="font-mono text-cyan-800 font-bold text-xs">{percentage.toFixed(1)}%</span>
              </div>
              <div className="w-full h-2 rounded-full bg-slate-200 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-cyan-500 to-blue-600 rounded-full transition-all duration-500"
                  style={{ width: `${percentage}%` }}
                />
              </div>
            </div>

            {/* Metrics pills */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <div className="p-2 rounded-xl bg-slate-50 border border-slate-200 text-center">
                <p className="text-[10px] text-slate-400 font-medium">Pastas</p>
                <p className="text-sm font-bold text-slate-800">{currentFolders.length}</p>
              </div>
              <div className="p-2 rounded-xl bg-slate-50 border border-slate-200 text-center">
                <p className="text-[10px] text-slate-400 font-medium">Arquivos</p>
                <p className="text-sm font-bold text-slate-800">{currentFiles.length}</p>
              </div>
            </div>
          </div>

          {/* Section 2: Custom Background Wallpaper & Zoom Adjuster */}
          <div className={`p-4 rounded-2xl border space-y-3 ${
            workspaceScope === 'team'
              ? 'bg-cyan-50/60 border-cyan-200'
              : 'bg-emerald-50/60 border-emerald-200'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ImageIcon className={`w-4 h-4 ${workspaceScope === 'team' ? 'text-cyan-700' : 'text-emerald-700'}`} />
                <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  {workspaceScope === 'team'
                    ? 'Fundo da Equipe (Para Todos)'
                    : 'Fundo Pessoal Privado'}
                </span>
              </div>
              {bgSettings.imageUrl && (
                <button
                  type="button"
                  onClick={() =>
                    onUpdateBgSettings({
                      imageUrl: null,
                      zoom: 100,
                      blur: 0,
                      overlayOpacity: 10,
                    })
                  }
                  className="text-[11px] font-semibold text-rose-600 hover:text-rose-700 cursor-pointer"
                >
                  Remover Fundo
                </button>
              )}
            </div>

            <p className="text-[11px] text-slate-600">
              {workspaceScope === 'team'
                ? 'As alterações feitas aqui são sincronizadas instantaneamente e refletidas para todos os usuários da equipe (inclusive novos acessos).'
                : 'As personalizações feitas aqui são salvas na sua conta e acompanham automaticamente todos os seus dispositivos (celular, tablet e computador) logados com o mesmo e-mail.'}
            </p>

            {/* Upload Custom Image input */}
            <div>
              <input
                ref={bgFileInputRef}
                type="file"
                accept="image/*"
                onChange={handleBgFileSelect}
                className="hidden"
                id="custom-bg-file-input"
              />
              <button
                type="button"
                onClick={() => bgFileInputRef.current?.click()}
                disabled={isCompressingBg}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold text-slate-800 bg-white hover:bg-slate-50 border border-cyan-300 shadow-2xs transition-all cursor-pointer disabled:opacity-50"
              >
                <Upload className="w-4 h-4 text-cyan-700" />
                <span>{isCompressingBg ? 'Otimizando imagem (<1MB)...' : 'Carregar Imagem do Meu Dispositivo'}</span>
              </button>
            </div>

            {/* Preset Wallpapers */}
            <div>
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                Modelos Sugeridos
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                {presetWallpapers.map((p, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() =>
                      onUpdateBgSettings({
                        ...bgSettings,
                        imageUrl: p.url,
                      })
                    }
                    className="group relative h-12 rounded-xl overflow-hidden border border-slate-300 hover:border-cyan-500 transition-all cursor-pointer"
                  >
                    <img src={p.url} alt={p.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center p-1">
                      <span className="text-[9px] font-bold text-white leading-tight text-center drop-shadow-xs">
                        {p.name}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Zoom / Scale and Blur Controls (Active when a background image is set) */}
            {bgSettings.imageUrl && (
              <div className="p-3 rounded-xl bg-white border border-cyan-200 space-y-3 animate-in fade-in">
                {/* Zoom / Scale */}
                <div>
                  <div className="flex justify-between items-center text-xs mb-1">
                    <span className="text-slate-700 font-semibold flex items-center gap-1.5">
                      <ZoomIn className="w-3.5 h-3.5 text-cyan-600" />
                      Zoom / Escala do Fundo
                    </span>
                    <span className="font-mono text-cyan-800 font-bold text-xs">{bgSettings.zoom}%</span>
                  </div>
                  <input
                    type="range"
                    min="100"
                    max="200"
                    step="5"
                    value={bgSettings.zoom}
                    onChange={(e) =>
                      onUpdateBgSettings({
                        ...bgSettings,
                        zoom: Number(e.target.value),
                      })
                    }
                    className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-cyan-600"
                  />
                </div>

                {/* Desfoque / Blur */}
                <div>
                  <div className="flex justify-between items-center text-xs mb-1">
                    <span className="text-slate-700 font-semibold flex items-center gap-1.5">
                      <Sliders className="w-3.5 h-3.5 text-cyan-600" />
                      Desfoque Suave
                    </span>
                    <span className="font-mono text-cyan-800 font-bold text-xs">{bgSettings.blur}px</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="16"
                    step="1"
                    value={bgSettings.blur}
                    onChange={(e) =>
                      onUpdateBgSettings({
                        ...bgSettings,
                        blur: Number(e.target.value),
                      })
                    }
                    className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-cyan-600"
                  />
                </div>

                {/* Película de Leveza / Contrast Overlay */}
                <div>
                  <div className="flex justify-between items-center text-xs mb-1">
                    <span className="text-slate-700 font-semibold text-[11px]">
                      Clarear Fundo (Garantir Leitura de Textos)
                    </span>
                    <span className="font-mono text-cyan-800 font-bold text-xs">{bgSettings.overlayOpacity}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="80"
                    step="5"
                    value={bgSettings.overlayOpacity}
                    onChange={(e) =>
                      onUpdateBgSettings({
                        ...bgSettings,
                        overlayOpacity: Number(e.target.value),
                      })
                    }
                    className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-cyan-600"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Section 3: Clean Slate / Remove Sample Data */}
          <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-3">
            <div className="flex items-start gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-100 border border-amber-300 flex items-center justify-center text-amber-700 shrink-0 mt-0.5">
                <Trash2 className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-xs font-bold text-slate-900">Limpar Amostras e Usuários Fictícios</h4>
                <p className="text-[11px] text-slate-600 mt-0.5 leading-relaxed">
                  Zere todos os arquivos de teste e colaboradores fictícios para deixar seu espaço 100% limpo para uso real.
                </p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-2 pt-1">
              <button
                type="button"
                onClick={handleClear}
                disabled={isClearing}
                className="flex-1 flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 shadow-xs transition-all cursor-pointer disabled:opacity-50"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{isClearing ? 'Limpando...' : 'Remover Todas as Amostras'}</span>
              </button>

              <button
                type="button"
                onClick={handleRestore}
                disabled={isRestoring}
                className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 shadow-2xs transition-all cursor-pointer disabled:opacity-50"
              >
                <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                <span>Restaurar Amostras</span>
              </button>
            </div>
          </div>

          {/* Section 4: Workspace Scope Switcher */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
              Modo de Trabalho
            </span>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setWorkspaceScope('team')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-1 ${
                  workspaceScope === 'team'
                    ? 'bg-cyan-50 border-cyan-400 text-cyan-950 font-semibold shadow-xs'
                    : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-1.5 text-xs">
                  <Layers className="w-4 h-4 text-cyan-600" />
                  <span>Modo Equipe</span>
                </div>
                <span className="text-[10px] text-slate-500 font-normal">Pastas abertas e colaborativas</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  if (!personalUser) {
                    onOpenAuthModal();
                  } else {
                    setWorkspaceScope('personal');
                  }
                }}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-1 ${
                  workspaceScope === 'personal'
                    ? 'bg-emerald-50 border-emerald-400 text-emerald-950 font-semibold shadow-xs'
                    : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-1.5 text-xs">
                  <Shield className="w-4 h-4 text-emerald-600" />
                  <span>Modo Pessoal</span>
                </div>
                <span className="text-[10px] text-slate-500 font-normal">
                  {personalUser ? personalUser.name : 'Cofre privado (Login)'}
                </span>
              </button>
            </div>

            {/* Personal user status / logout */}
            {workspaceScope === 'personal' && personalUser && (
              <div className="p-2.5 rounded-xl bg-white border border-emerald-200 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <img
                    src={personalUser.avatar}
                    alt={personalUser.name}
                    className="w-6 h-6 rounded-full object-cover ring-1 ring-emerald-400 shrink-0"
                  />
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-slate-900 truncate">{personalUser.name}</p>
                    <p className="text-[10px] text-slate-500 truncate">{personalUser.email}</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={onLogoutPersonal}
                  className="text-xs text-rose-600 hover:text-rose-700 font-semibold px-2 py-1 rounded-lg hover:bg-rose-50"
                >
                  Sair
                </button>
              </div>
            )}
          </div>

          {/* Section 5: Members & Collaboration */}
          {workspaceScope === 'team' && (
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Membros da Equipe ({teamData.members.length})
                </span>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenTeam();
                  }}
                  className="text-xs font-semibold text-cyan-700 hover:text-cyan-800 flex items-center gap-1 cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Convidar / Feed</span>
                </button>
              </div>

              <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                {teamData.members.map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => onSelectMember(m)}
                    className={`w-full flex items-center justify-between p-2 rounded-xl text-xs transition-all cursor-pointer ${
                      activeMember.id === m.id
                        ? 'bg-cyan-50 border border-cyan-300 font-semibold text-cyan-900'
                        : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <img src={m.avatar} alt={m.name} className="w-5 h-5 rounded-full object-cover shrink-0" />
                      <span className="truncate">{m.name}</span>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono shrink-0">{m.role}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Section 6: Utilities & Export */}
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => {
                onClose();
                onDownloadAllAsZip();
              }}
              className="flex items-center justify-center gap-1.5 p-3 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 transition-all cursor-pointer shadow-2xs"
            >
              <DownloadCloud className="w-4 h-4 text-cyan-600" />
              <span>Baixar Tudo (ZIP)</span>
            </button>

            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenIE11Modal();
              }}
              className={`flex items-center justify-center gap-1.5 p-3 rounded-xl border text-xs font-semibold transition-all cursor-pointer shadow-2xs ${
                isIE11Mode
                  ? 'bg-amber-50 text-amber-800 border-amber-300'
                  : 'bg-white text-slate-800 border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Monitor className="w-4 h-4 text-amber-600" />
              <span>Modo IE11 {isIE11Mode ? 'ON' : ''}</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50/80 flex items-center justify-between text-xs text-slate-500 shrink-0">
          <span className="font-mono text-[11px]">CrystalCloud v2.5</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl cursor-pointer"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};

