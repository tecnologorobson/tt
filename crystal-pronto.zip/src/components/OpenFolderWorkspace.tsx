import React, { useState } from 'react';
import {
  FolderOpen,
  Download,
  Upload,
  Trash2,
  ChevronDown,
  ChevronUp,
  FileText,
  Palette,
  Code,
  BarChart3,
  Shield,
} from 'lucide-react';
import { WorkspaceFile, WorkspaceFolder, TeamMember, FileCategory } from '../types';
import { FileSquircleCard } from './FileSquircleCard';
import { formatBytes, downloadFolderAsZip } from '../utils/fileUtils';

interface OpenFolderWorkspaceProps {
  folders: WorkspaceFolder[];
  files: WorkspaceFile[];
  activeMember: TeamMember;
  searchQuery: string;
  selectedCategory: FileCategory | 'all';
  onPreviewFile: (file: WorkspaceFile) => void;
  onOpenVersions: (file: WorkspaceFile) => void;
  onToggleLock: (file: WorkspaceFile) => void;
  onOpenComments: (file: WorkspaceFile) => void;
  onDeleteFile: (file: WorkspaceFile) => void;
  onUploadToFolder: (folderId: string) => void;
  onDeleteFolder: (folderId: string) => void;
  onToggleFolderOpen: (folderId: string) => void;
  onDropFilesOnFolder: (folderId: string, fileList: FileList) => void;
}

export const OpenFolderWorkspace: React.FC<OpenFolderWorkspaceProps> = ({
  folders,
  files,
  activeMember,
  searchQuery,
  selectedCategory,
  onPreviewFile,
  onOpenVersions,
  onToggleLock,
  onOpenComments,
  onDeleteFile,
  onUploadToFolder,
  onDeleteFolder,
  onToggleFolderOpen,
  onDropFilesOnFolder,
}) => {
  const [dragOverFolderId, setDragOverFolderId] = useState<string | null>(null);

  const getFolderIcon = (iconName: string) => {
    switch (iconName) {
      case 'Palette':
        return <Palette className="w-4 h-4 text-cyan-700" />;
      case 'FileText':
        return <FileText className="w-4 h-4 text-emerald-700" />;
      case 'Code':
        return <Code className="w-4 h-4 text-amber-700" />;
      case 'BarChart3':
        return <BarChart3 className="w-4 h-4 text-violet-700" />;
      case 'Shield':
        return <Shield className="w-4 h-4 text-emerald-700" />;
      default:
        return <FolderOpen className="w-4 h-4 text-cyan-700" />;
    }
  };

  const getFilteredFolderFiles = (folderId: string) => {
    return files.filter((f) => {
      if (f.folderId !== folderId) return false;
      if (selectedCategory !== 'all' && f.category !== selectedCategory) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = (f.name || '').toLowerCase().includes(q);
        const matchesExt = (f.extension || '').toLowerCase().includes(q);
        const matchesTag = Array.isArray(f.tags) && f.tags.some((t) => (t || '').toLowerCase().includes(q));
        const authorName = f.createdBy?.name || f.updatedBy?.name || '';
        const matchesAuthor = authorName.toLowerCase().includes(q);
        if (!matchesName && !matchesExt && !matchesTag && !matchesAuthor) return false;
      }
      return true;
    });
  };

  const handleDragOver = (e: React.DragEvent, folderId: string) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOverFolderId(folderId);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOverFolderId(null);
  };

  const handleDrop = (e: React.DragEvent, folderId: string) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOverFolderId(null);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onDropFilesOnFolder(folderId, e.dataTransfer.files);
    }
  };

  if (folders.length === 0) {
    return (
      <div className="crystal-squircle p-8 sm:p-12 text-center flex flex-col items-center justify-center space-y-4 my-6">
        <div className="w-16 h-16 rounded-3xl bg-cyan-50 border border-cyan-200 flex items-center justify-center text-cyan-600 shadow-sm">
          <FolderOpen className="w-8 h-8" />
        </div>
        <div className="space-y-1 max-w-md">
          <h3 className="text-base sm:text-lg font-bold text-slate-900">Seu Workspace está limpo e pronto!</h3>
          <p className="text-xs sm:text-sm text-slate-500">
            Você não possui pastas ou arquivos de amostra. Crie uma pasta para começar a organizar e enviar seus arquivos.
          </p>
        </div>
        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          <button
            type="button"
            onClick={() => onUploadToFolder('default')}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm text-white bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 shadow-md shadow-cyan-600/20 cursor-pointer transition-all"
          >
            <Upload className="w-4 h-4" />
            <span>Enviar Meu Primeiro Arquivo</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {folders.map((folder) => {
        const folderFiles = getFilteredFolderFiles(folder.id);
        const totalSize = folderFiles.reduce((sum, f) => sum + f.sizeBytes, 0);
        const isDragActive = dragOverFolderId === folder.id;

        return (
          <section
            key={folder.id}
            id={`open-folder-${folder.id}`}
            onDragOver={(e) => handleDragOver(e, folder.id)}
            onDragLeave={handleDragLeave}
            onDrop={(e) => handleDrop(e, folder.id)}
            className={`crystal-squircle p-4 sm:p-5 transition-all duration-300 ${
              isDragActive
                ? 'border-cyan-400 bg-cyan-50/70 ring-2 ring-cyan-400/50 shadow-md'
                : 'hover:border-slate-300'
            }`}
          >
            {/* Top Accent Line */}
            <div
              className={`absolute top-0 left-6 right-6 h-0.5 rounded-full bg-gradient-to-r ${folder.colorAccent} opacity-90`}
            />

            {/* Folder Header */}
            <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-200/80">
              <div className="flex items-center gap-3">
                <div
                  className={`w-9 h-9 rounded-xl bg-slate-100 border border-slate-200/90 flex items-center justify-center shadow-xs cursor-pointer hover:bg-slate-200/70 transition-colors`}
                  onClick={() => onToggleFolderOpen(folder.id)}
                >
                  {getFolderIcon(folder.icon)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3
                      className="text-sm sm:text-base font-bold text-slate-850 text-slate-900 tracking-tight cursor-pointer hover:text-cyan-700 transition-colors"
                      onClick={() => onToggleFolderOpen(folder.id)}
                    >
                      {folder.name}
                    </h3>
                    <span className="px-2 py-0.5 text-[11px] font-bold rounded-md bg-slate-100 text-cyan-800 border border-slate-200">
                      {folderFiles.length}
                    </span>
                    <span className="text-[11px] text-slate-500 font-mono hidden sm:inline">
                      {formatBytes(totalSize)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Folder Actions */}
              <div className="flex items-center gap-1.5">
                <button
                  id={`btn-upload-folder-${folder.id}`}
                  type="button"
                  onClick={() => onUploadToFolder(folder.id)}
                  className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 rounded-lg border border-slate-200 transition-all cursor-pointer shadow-2xs"
                  title="Upload nesta pasta"
                >
                  <Upload className="w-3.5 h-3.5 text-cyan-600" />
                  <span className="hidden sm:inline">Upload</span>
                </button>

                <button
                  id={`btn-download-zip-folder-${folder.id}`}
                  type="button"
                  onClick={() => downloadFolderAsZip(folder, files)}
                  className="p-1.5 rounded-lg text-cyan-700 bg-cyan-50 hover:bg-cyan-100 border border-cyan-200 transition-all cursor-pointer shadow-2xs"
                  title="Baixar pasta em ZIP"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>

                {folders.length > 1 && (
                  <button
                    id={`btn-delete-folder-${folder.id}`}
                    type="button"
                    onClick={() => onDeleteFolder(folder.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-all cursor-pointer"
                    title="Excluir pasta"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => onToggleFolderOpen(folder.id)}
                  className="p-1.5 rounded-lg text-slate-600 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-200 transition-all cursor-pointer shadow-2xs"
                  title={folder.isOpen ? 'Recolher' : 'Expandir'}
                >
                  {folder.isOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* Folder Contents */}
            {folder.isOpen && (
              <div className="mt-4">
                {isDragActive && (
                  <div className="mb-3 p-3 rounded-xl border border-dashed border-cyan-400 bg-cyan-50 text-cyan-800 text-xs text-center font-medium animate-pulse">
                    Solte os arquivos para upload e versionamento automático
                  </div>
                )}

                {folderFiles.length === 0 ? (
                  <div
                    onClick={() => onUploadToFolder(folder.id)}
                    className="py-8 px-4 rounded-2xl border border-dashed border-slate-300 bg-slate-50/50 flex flex-col items-center justify-center text-center cursor-pointer hover:border-cyan-400 hover:bg-cyan-50/30 transition-all"
                  >
                    <Upload className="w-5 h-5 text-slate-400" />
                    <p className="mt-2 text-xs font-semibold text-slate-600">Pasta vazia</p>
                    <p className="text-[11px] text-slate-400">Clique para enviar arquivos ou arraste aqui</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                    {folderFiles.map((file) => (
                      <FileSquircleCard
                        key={file.id}
                        file={file}
                        activeMember={activeMember}
                        onPreview={onPreviewFile}
                        onOpenVersions={onOpenVersions}
                        onToggleLock={onToggleLock}
                        onOpenComments={onOpenComments}
                        onDelete={onDeleteFile}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}
          </section>
        );
      })}
    </div>
  );
};
