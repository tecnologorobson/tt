import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Navbar } from './components/Navbar';
import { StorageStatsBar } from './components/StorageStatsBar';
import { OpenFolderWorkspace } from './components/OpenFolderWorkspace';
import { UploadModal } from './components/UploadModal';
import { VersionHistoryModal } from './components/VersionHistoryModal';
import { FilePreviewModal } from './components/FilePreviewModal';
import { TeamCollaborationDrawer } from './components/TeamCollaborationDrawer';
import { IE11CompatibilityPanel } from './components/IE11CompatibilityPanel';
import { NewFolderModal } from './components/NewFolderModal';
import { PersonalAuthModal } from './components/PersonalAuthModal';
import { InfoHubModal } from './components/InfoHubModal';
import { initialWorkspaceData } from './data/initialData';
import {
  BackgroundSettings,
  DEFAULT_BACKGROUND_SETTINGS,
} from './utils/imageOptimizer';
import {
  WorkspaceData,
  WorkspaceFile,
  WorkspaceFolder,
  TeamMember,
  FileCategory,
  WorkspaceScope,
  PersonalUser,
} from './types';
import { triggerFileDownload, resolveFileBlob } from './utils/fileUtils';
import JSZip from 'jszip';

export default function App() {
  // Mode selection: Shared Team Workspace vs. Personal Mode (Vault) - persisted in browser
  const [workspaceScope, setWorkspaceScope] = useState<WorkspaceScope>(() => {
    try {
      const savedScope = localStorage.getItem('crystalcloud_last_workspace_scope');
      if (savedScope === 'personal' || savedScope === 'team') {
        return savedScope;
      }
    } catch {
      // ignore
    }
    return 'team';
  });

  // Personal user authentication state (persisted locally)
  const [personalUser, setPersonalUser] = useState<PersonalUser | null>(() => {
    try {
      const saved = localStorage.getItem('crystal_personal_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Team workspace shared state
  const [teamData, setTeamData] = useState<WorkspaceData>(initialWorkspaceData);

  // Personal workspace state
  const [personalFolders, setPersonalFolders] = useState<WorkspaceFolder[]>([]);
  const [personalFiles, setPersonalFiles] = useState<WorkspaceFile[]>([]);
  const [personalStorageUsed, setPersonalStorageUsed] = useState<number>(4570);
  const [personalStorageLimit, setPersonalStorageLimit] = useState<number>(15 * 1024 * 1024 * 1024);

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<FileCategory | 'all'>('all');
  const [isIE11Mode, setIsIE11Mode] = useState<boolean>(() => {
    try {
      return localStorage.getItem('crystalcloud_ie11_mode') === 'true';
    } catch {
      return false;
    }
  });

  // Active simulated collaborator (team mode)
  const [activeMember, setActiveMember] = useState<TeamMember>(initialWorkspaceData.members[0]);

  // Team Background Settings (synced across server and all team members)
  const [teamBgSettings, setTeamBgSettings] = useState<BackgroundSettings>(() => {
    return initialWorkspaceData.bgSettings || DEFAULT_BACKGROUND_SETTINGS;
  });

  // Personal Background Settings (isolated per user account, synced across all devices with same email)
  const [personalBgSettings, setPersonalBgSettings] = useState<BackgroundSettings>(() => {
    try {
      const savedUser = localStorage.getItem('crystal_personal_user');
      const emailKey = savedUser ? JSON.parse(savedUser).email : '04testes@gmail.com';
      const saved = localStorage.getItem(`crystalcloud_personal_bg_${emailKey?.toLowerCase()}`);
      return saved ? JSON.parse(saved) : DEFAULT_BACKGROUND_SETTINGS;
    } catch {
      return DEFAULT_BACKGROUND_SETTINGS;
    }
  });

  // Active Background Settings depending on current workspace scope
  const activeBgSettings = workspaceScope === 'personal' ? personalBgSettings : teamBgSettings;

  const handleUpdateBgSettings = async (settings: BackgroundSettings) => {
    if (workspaceScope === 'team') {
      // 1. Update Team appearance and broadcast to all users via WebSocket
      setTeamBgSettings(settings);
      setTeamData((prev) => ({ ...prev, bgSettings: settings }));
      try {
        await fetch('/api/workspace/settings', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ bgSettings: settings }),
        });
      } catch (err) {
        console.error('Erro ao sincronizar configurações da equipe:', err);
      }
    } else {
      // 2. Update Personal appearance for this logged user (synced across all devices with same email)
      setPersonalBgSettings(settings);
      const targetEmail = personalUser?.email || '04testes@gmail.com';
      const uid = personalUser?.id || 'usr-04testes';
      try {
        localStorage.setItem(`crystalcloud_personal_bg_${targetEmail.toLowerCase()}`, JSON.stringify(settings));
        await fetch('/api/personal/settings', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId: uid, email: targetEmail, bgSettings: settings }),
        });
      } catch (err) {
        console.error('Erro ao salvar preferências pessoais:', err);
      }
    }
  };

  // Modals state
  const [isInfoHubOpen, setIsInfoHubOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [uploadTargetFolderId, setUploadTargetFolderId] = useState<string | undefined>(undefined);
  const [isNewFolderOpen, setIsNewFolderOpen] = useState(false);
  const [isTeamDrawerOpen, setIsTeamDrawerOpen] = useState(false);
  const [isIE11ModalOpen, setIsIE11ModalOpen] = useState(false);
  const [selectedFileForVersions, setSelectedFileForVersions] = useState<WorkspaceFile | null>(null);
  const [selectedFileForPreview, setSelectedFileForPreview] = useState<WorkspaceFile | null>(null);

  const socketRef = useRef<WebSocket | null>(null);
  const pingIntervalRef = useRef<any>(null);

  // Active files & folders based on current mode
  const currentFolders = workspaceScope === 'personal' ? personalFolders : teamData.folders;
  const currentFiles = workspaceScope === 'personal' ? personalFiles : teamData.files;
  const currentUsedStorage =
    workspaceScope === 'personal' ? personalStorageUsed : teamData.syncState.cloudStorageUsedBytes;
  const currentLimitStorage =
    workspaceScope === 'personal' ? personalStorageLimit : teamData.syncState.cloudStorageLimitBytes;

  // 1. Fetch Team Workspace via REST
  const fetchTeamWorkspace = useCallback(async () => {
    try {
      setTeamData((prev) => ({ ...prev, syncState: { ...prev.syncState, status: 'syncing' } }));
      const res = await fetch('/api/workspace');
      if (res.ok) {
        const json = await res.json();
        setTeamData(json);
        if (json.bgSettings) {
          setTeamBgSettings(json.bgSettings);
        }
      }
    } catch {
      setTeamData((prev) => ({ ...prev, syncState: { ...prev.syncState, status: 'offline' } }));
    }
  }, []);

  // 2. Fetch Personal Workspace via REST
  const fetchPersonalWorkspace = useCallback(async (userId?: string, email?: string) => {
    try {
      const uid = userId || personalUser?.id || 'usr-04testes';
      const targetEmail = email || personalUser?.email || '04testes@gmail.com';
      const queryParams = new URLSearchParams();
      if (uid) queryParams.set('userId', uid);
      if (targetEmail) queryParams.set('email', targetEmail);

      const res = await fetch(`/api/personal/workspace?${queryParams.toString()}`);
      if (res.ok) {
        const json = await res.json();
        setPersonalFolders(json.folders || []);
        setPersonalFiles(json.files || []);
        setPersonalStorageUsed(json.cloudStorageUsedBytes || 0);
        setPersonalStorageLimit(json.cloudStorageLimitBytes || 15 * 1024 * 1024 * 1024);
        if (json.bgSettings) {
          setPersonalBgSettings(json.bgSettings);
          try {
            localStorage.setItem(`crystalcloud_personal_bg_${targetEmail.toLowerCase()}`, JSON.stringify(json.bgSettings));
          } catch {
            // ignore
          }
        }
      }
    } catch {
      // ignore
    }
  }, [personalUser]);

  // 3. Team WebSocket Connection
  const connectWebSocket = useCallback(() => {
    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      const ws = new WebSocket(wsUrl);
      socketRef.current = ws;

      ws.onopen = () => {
        setTeamData((prev) => ({
          ...prev,
          syncState: { ...prev.syncState, status: 'synced', lastSyncedAt: new Date().toISOString() },
        }));

        ws.send(
          JSON.stringify({
            type: 'MEMBER_PRESENCE',
            memberId: activeMember.id,
            status: 'online',
          })
        );

        if (pingIntervalRef.current) clearInterval(pingIntervalRef.current);
        pingIntervalRef.current = setInterval(() => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ type: 'PING', clientTime: Date.now() }));
          }
        }, 8000);
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.type === 'SYNC_INIT') {
            setTeamData(msg.payload);
            if (msg.payload.bgSettings) {
              setTeamBgSettings(msg.payload.bgSettings);
            }
          } else if (msg.type === 'TEAM_SETTINGS_UPDATED') {
            if (msg.payload.bgSettings) {
              setTeamBgSettings(msg.payload.bgSettings);
              setTeamData((prev) => ({
                ...prev,
                bgSettings: msg.payload.bgSettings,
                syncState: msg.payload.syncState || prev.syncState,
                activities: msg.payload.activity ? [msg.payload.activity, ...prev.activities] : prev.activities,
              }));
            }
          } else if (msg.type === 'PERSONAL_SETTINGS_UPDATED') {
            const currentEmail = personalUser?.email?.toLowerCase() || '04testes@gmail.com';
            const currentUid = personalUser?.id || 'usr-04testes';
            if (
              (msg.payload.email && msg.payload.email.toLowerCase() === currentEmail) ||
              (msg.payload.userId && msg.payload.userId === currentUid)
            ) {
              if (msg.payload.bgSettings) {
                setPersonalBgSettings(msg.payload.bgSettings);
                try {
                  localStorage.setItem(`crystalcloud_personal_bg_${currentEmail}`, JSON.stringify(msg.payload.bgSettings));
                } catch {
                  // ignore
                }
              }
            }
          } else if (msg.type === 'PONG') {
            const rtt = Math.max(1, Date.now() - msg.clientTime);
            setTeamData((prev) => ({
              ...prev,
              syncState: { ...prev.syncState, latencyMs: rtt, status: 'synced', lastSyncedAt: new Date().toISOString() },
            }));
          } else if (msg.type === 'PRESENCE_UPDATE') {
            setTeamData((prev) => ({
              ...prev,
              syncState: {
                ...prev.syncState,
                connectedClients: msg.payload.connectedClients,
                lastSyncedAt: msg.payload.lastSyncedAt,
              },
            }));
          } else if (msg.type === 'FILE_CREATED') {
            setTeamData((prev) => {
              const fileExists = prev.files.some((f) => f.id === msg.payload.file.id);
              const newFiles = fileExists ? prev.files : [msg.payload.file, ...prev.files];
              return {
                ...prev,
                files: newFiles,
                activities: [msg.payload.activity, ...prev.activities],
                syncState: { ...prev.syncState, lastSyncedAt: new Date().toISOString() },
              };
            });
          } else if (msg.type === 'FILE_VERSIONED' || msg.type === 'FILE_REVERTED') {
            setTeamData((prev) => {
              const newFiles = prev.files.map((f) => (f.id === msg.payload.file.id ? msg.payload.file : f));
              return {
                ...prev,
                files: newFiles,
                activities: [msg.payload.activity, ...prev.activities],
                syncState: { ...prev.syncState, lastSyncedAt: new Date().toISOString() },
              };
            });
            setSelectedFileForPreview((cur) => (cur?.id === msg.payload.file.id ? msg.payload.file : cur));
            setSelectedFileForVersions((cur) => (cur?.id === msg.payload.file.id ? msg.payload.file : cur));
          } else if (msg.type === 'FILE_LOCK_TOGGLED') {
            setTeamData((prev) => ({
              ...prev,
              files: prev.files.map((f) => (f.id === msg.payload.file.id ? msg.payload.file : f)),
              activities: [msg.payload.activity, ...prev.activities],
            }));
            setSelectedFileForPreview((cur) => (cur?.id === msg.payload.file.id ? msg.payload.file : cur));
          } else if (msg.type === 'COMMENT_ADDED') {
            setTeamData((prev) => ({
              ...prev,
              files: prev.files.map((f) =>
                f.id === msg.payload.fileId ? { ...f, comments: [...f.comments, msg.payload.comment] } : f
              ),
              activities: [msg.payload.activity, ...prev.activities],
            }));
            setSelectedFileForPreview((cur) =>
              cur?.id === msg.payload.fileId ? { ...cur, comments: [...cur.comments, msg.payload.comment] } : cur
            );
          } else if (msg.type === 'FOLDER_CREATED') {
            setTeamData((prev) => ({
              ...prev,
              folders: [...prev.folders, msg.payload.folder],
              activities: [msg.payload.activity, ...prev.activities],
            }));
          } else if (msg.type === 'FOLDER_DELETED') {
            setTeamData((prev) => ({
              ...prev,
              folders: prev.folders.filter((f) => f.id !== msg.payload.folderId),
              files: prev.files.filter((f) => f.folderId !== msg.payload.folderId),
              activities: [msg.payload.activity, ...prev.activities],
            }));
          } else if (msg.type === 'FILE_DELETED') {
            setTeamData((prev) => ({
              ...prev,
              files: prev.files.filter((f) => f.id !== msg.payload.fileId),
              activities: [msg.payload.activity, ...prev.activities],
            }));
          }
        } catch {
          // ignore
        }
      };

      ws.onerror = () => {
        setTeamData((prev) => ({ ...prev, syncState: { ...prev.syncState, status: 'offline' } }));
      };

      ws.onclose = () => {
        setTeamData((prev) => ({ ...prev, syncState: { ...prev.syncState, status: 'offline' } }));
        setTimeout(connectWebSocket, 4000);
      };
    } catch {
      // Fallback
    }
  }, [activeMember]);

  useEffect(() => {
    fetchTeamWorkspace();
    fetchPersonalWorkspace();
    connectWebSocket();
    return () => {
      if (socketRef.current) socketRef.current.close();
      if (pingIntervalRef.current) clearInterval(pingIntervalRef.current);
    };
  }, [fetchTeamWorkspace, fetchPersonalWorkspace, connectWebSocket]);

  // Persist workspace mode (Team vs. Personal) in browser storage
  useEffect(() => {
    try {
      localStorage.setItem('crystalcloud_last_workspace_scope', workspaceScope);
    } catch {
      // ignore
    }
  }, [workspaceScope]);

  // Apply IE11 simulation class to document element and persist preference
  useEffect(() => {
    try {
      localStorage.setItem('crystalcloud_ie11_mode', isIE11Mode ? 'true' : 'false');
    } catch {
      // ignore
    }
    if (isIE11Mode) {
      document.documentElement.classList.add('ie11-mode');
    } else {
      document.documentElement.classList.remove('ie11-mode');
    }
  }, [isIE11Mode]);

  // Auth Handlers
  const handleLoginSuccess = (user: PersonalUser) => {
    setPersonalUser(user);
    try {
      localStorage.setItem('crystal_personal_user', JSON.stringify(user));
    } catch {
      // ignore
    }
    setWorkspaceScope('personal');
    fetchPersonalWorkspace(user.id, user.email);
    if (user.bgSettings) {
      setPersonalBgSettings(user.bgSettings);
      try {
        localStorage.setItem(`crystalcloud_personal_bg_${user.email.toLowerCase()}`, JSON.stringify(user.bgSettings));
      } catch {
        // ignore
      }
    } else {
      try {
        const saved = localStorage.getItem(`crystalcloud_personal_bg_${user.email.toLowerCase()}`);
        if (saved) {
          setPersonalBgSettings(JSON.parse(saved));
        } else {
          setPersonalBgSettings(DEFAULT_BACKGROUND_SETTINGS);
        }
      } catch {
        setPersonalBgSettings(DEFAULT_BACKGROUND_SETTINGS);
      }
    }
  };

  const handleLogoutPersonal = () => {
    setPersonalUser(null);
    try {
      localStorage.removeItem('crystal_personal_user');
    } catch {
      // ignore
    }
    setWorkspaceScope('team');
  };

  // 4. File Upload Batch Handler (Team & Personal)
  const handleUploadBatch = async (
    items: {
      folderId: string;
      name: string;
      sizeBytes: number;
      mimeType: string;
      content?: string;
      previewUrl?: string;
      changeSummary?: string;
    }[]
  ) => {
    if (workspaceScope === 'personal') {
      const uid = personalUser?.id || 'usr-04testes';
      for (const item of items) {
        await fetch('/api/personal/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...item,
            userId: uid,
          }),
        });
      }
      fetchPersonalWorkspace(uid);
    } else {
      for (const item of items) {
        await fetch('/api/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...item,
            author: {
              id: activeMember.id,
              name: activeMember.name,
              avatar: activeMember.avatar,
              role: activeMember.role,
            },
          }),
        });
      }
    }
  };

  // 5. Revert File Version
  const handleRevertVersion = async (fileId: string, versionNumber: number) => {
    if (workspaceScope === 'personal') {
      const uid = personalUser?.id || 'usr-04testes';
      await fetch(`/api/personal/files/${fileId}/revert`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ versionNumber, userId: uid }),
      });
      fetchPersonalWorkspace(uid);
    } else {
      await fetch(`/api/files/${fileId}/revert`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ versionNumber }),
      });
    }
  };

  // 6. Save In-App Revision
  const handleSaveRevision = async (fileId: string, newContent: string, summary: string) => {
    const file = currentFiles.find((f) => f.id === fileId);
    if (!file) return;

    if (workspaceScope === 'personal') {
      const uid = personalUser?.id || 'usr-04testes';
      await fetch('/api/personal/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: uid,
          folderId: file.folderId,
          name: file.name,
          sizeBytes: new Blob([newContent]).size,
          mimeType: file.mimeType,
          content: newContent,
          changeSummary: summary,
        }),
      });
      fetchPersonalWorkspace(uid);
    } else {
      await fetch('/api/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          folderId: file.folderId,
          name: file.name,
          sizeBytes: new Blob([newContent]).size,
          mimeType: file.mimeType,
          content: newContent,
          changeSummary: summary,
          author: {
            id: activeMember.id,
            name: activeMember.name,
            avatar: activeMember.avatar,
            role: activeMember.role,
          },
        }),
      });
    }
  };

  // 7. Toggle File Lock (Team mode)
  const handleToggleLock = async (file: WorkspaceFile) => {
    if (workspaceScope === 'personal') return;
    await fetch(`/api/files/${file.id}/lock`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });
  };

  // 8. Add Comment
  const handleAddComment = async (fileId: string, content: string) => {
    if (workspaceScope === 'personal') return;
    await fetch(`/api/files/${fileId}/comments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        content,
        author: {
          id: activeMember.id,
          name: activeMember.name,
          avatar: activeMember.avatar,
          role: activeMember.role,
        },
      }),
    });
  };

  // 9. Delete File
  const handleDeleteFile = async (file: WorkspaceFile) => {
    if (confirm(`Deseja realmente excluir "${file.name}"?`)) {
      if (workspaceScope === 'personal') {
        const uid = personalUser?.id || 'usr-04testes';
        await fetch(`/api/personal/files/${file.id}`, { method: 'DELETE' });
        fetchPersonalWorkspace(uid);
      } else {
        await fetch(`/api/files/${file.id}`, { method: 'DELETE' });
      }
    }
  };

  // 10. Create Folder
  const handleCreateFolder = async (name: string, description: string, colorAccent: string, icon: string) => {
    if (workspaceScope === 'personal') {
      const uid = personalUser?.id || 'usr-04testes';
      await fetch('/api/personal/folders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: uid, name, description, colorAccent, icon }),
      });
      fetchPersonalWorkspace(uid);
    } else {
      await fetch('/api/folders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, description, colorAccent, icon }),
      });
    }
  };

  // 11. Delete Folder
  const handleDeleteFolder = async (folderId: string) => {
    const folder = currentFolders.find((f) => f.id === folderId);
    if (confirm(`Excluir a pasta "${folder?.name || ''}" e todos os seus arquivos?`)) {
      if (workspaceScope === 'personal') {
        const uid = personalUser?.id || 'usr-04testes';
        await fetch(`/api/personal/folders/${folderId}`, { method: 'DELETE' });
        fetchPersonalWorkspace(uid);
      } else {
        await fetch(`/api/folders/${folderId}`, { method: 'DELETE' });
      }
    }
  };

  // 12. Toggle Folder Open/Collapse
  const handleToggleFolderOpen = (folderId: string) => {
    if (workspaceScope === 'personal') {
      setPersonalFolders((prev) =>
        prev.map((f) => (f.id === folderId ? { ...f, isOpen: !f.isOpen } : f))
      );
    } else {
      setTeamData((prev) => ({
        ...prev,
        folders: prev.folders.map((f) => (f.id === folderId ? { ...f, isOpen: !f.isOpen } : f)),
      }));
    }
  };

  // 13. Drop files on folder handler (reads files as base64 Data URLs to avoid corruption)
  const handleDropFilesOnFolder = async (folderId: string, fileList: FileList) => {
    const chosenFolderFiles = currentFiles.filter((f) => f.folderId === folderId);

    const uploads = await Promise.all(
      Array.from(fileList).map(async (file) => {
        const existing = chosenFolderFiles.find((ef) => ef.name.toLowerCase() === file.name.toLowerCase());
        const isDuplicate = !!existing;

        const dataUrl = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = (e) => resolve((e.target?.result as string) || '');
          reader.onerror = () => resolve('');
          reader.readAsDataURL(file);
        });

        return {
          folderId,
          name: file.name,
          sizeBytes: file.size,
          mimeType: file.type || 'application/octet-stream',
          content: dataUrl,
          previewUrl: file.type.startsWith('image/') ? dataUrl : undefined,
          changeSummary: isDuplicate
            ? `Upload: Criou automaticamente a revisão v${(existing?.currentVersion || 1) + 1}.`
            : 'Upload inicial do arquivo.',
        };
      })
    );

    handleUploadBatch(uploads);
  };

  // 14. Batch Download Workspace as ZIP (uncorrupted binary & text files)
  const handleDownloadAllAsZip = async () => {
    const zip = new JSZip();

    const rootManifest = {
      workspace: workspaceScope === 'personal' ? 'CrystalCloud Cofre Pessoal' : 'CrystalCloud Workspace Equipe',
      owner: workspaceScope === 'personal' ? personalUser?.email || 'Pessoal' : 'Workspace Compartilhado',
      exportedAt: new Date().toISOString(),
      foldersCount: currentFolders.length,
      filesCount: currentFiles.length,
      totalStorageBytes: currentUsedStorage,
      folders: currentFolders.map((f) => ({
        id: f.id,
        name: f.name,
        description: f.description,
        files: currentFiles
          .filter((fl) => fl.folderId === f.id)
          .map((fl) => ({
            name: fl.name,
            version: `v${fl.currentVersion}`,
            sizeBytes: fl.sizeBytes,
          })),
      })),
    };

    zip.file('_WORKSPACE_MANIFEST.json', JSON.stringify(rootManifest, null, 2));

    for (const folder of currentFolders) {
      const folderFiles = currentFiles.filter((f) => f.folderId === folder.id);
      const cleanFolderName = folder.name.replace(/[^a-zA-Z0-9_\-]/g, '_');
      const subFolder = zip.folder(cleanFolderName);

      for (const f of folderFiles) {
        try {
          const blob = await resolveFileBlob(f);
          const arrayBuffer = await blob.arrayBuffer();
          subFolder?.file(f.name, arrayBuffer);
        } catch {
          const payload = f.content || `Arquivo: ${f.name}\nVersão: v${f.currentVersion}\nAtualizado em: ${f.updatedAt}`;
          subFolder?.file(f.name, payload);
        }
      }
    }

    const blob = await zip.generateAsync({ type: 'blob' });
    const zipName =
      workspaceScope === 'personal'
        ? 'CrystalCloud_Cofre_Pessoal.zip'
        : 'CrystalCloud_Workspace_Equipe.zip';
    triggerFileDownload(zipName, blob, 'application/zip');
  };

  // 15. Add Team Member Simulation
  const handleAddMember = (name: string, email: string, role: TeamMember['role']) => {
    const newMember: TeamMember = {
      id: `user-${Date.now()}`,
      name,
      email,
      avatar: `https://images.unsplash.com/photo-${1535713875000 + Math.floor(Math.random() * 1000)}?w=150&auto=format&fit=crop&q=80`,
      role,
      status: 'online',
      activeFolderId: teamData.folders[0]?.id,
      lastActive: 'Agora mesmo',
    };

    setTeamData((prev) => ({
      ...prev,
      members: [...prev.members, newMember],
      activities: [
        {
          id: `act-${Date.now()}`,
          type: 'sync',
          userId: newMember.id,
          userName: newMember.name,
          userAvatar: newMember.avatar,
          targetId: newMember.id,
          targetName: newMember.name,
          details: `Novo integrante com cargo de ${role}.`,
          timestamp: new Date().toISOString(),
        },
        ...prev.activities,
      ],
    }));
  };

  // 16. Clear all samples and dummy users
  const handleClearSamples = async () => {
    try {
      const res = await fetch('/api/workspace/clear-samples', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ keepDefaultFolder: true }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.workspace) {
          setTeamData(data.workspace);
          if (data.workspace.members?.[0]) {
            setActiveMember(data.workspace.members[0]);
          }
        }
        await fetchPersonalWorkspace();
      }
    } catch (err) {
      console.error('Falha ao limpar amostras:', err);
    }
  };

  // 17. Restore sample workspace data
  const handleRestoreSamples = async () => {
    try {
      const res = await fetch('/api/workspace/restore-samples', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      if (res.ok) {
        const data = await res.json();
        if (data.workspace) {
          setTeamData(data.workspace);
          if (data.workspace.members?.[0]) {
            setActiveMember(data.workspace.members[0]);
          }
        }
        await fetchPersonalWorkspace();
      }
    } catch (err) {
      console.error('Falha ao restaurar amostras:', err);
    }
  };

  return (
    <div className="relative min-h-screen bg-slate-50 text-slate-800 flex flex-col selection:bg-cyan-500/20 selection:text-cyan-900 overflow-x-hidden">
      {/* Dynamic Custom Wallpaper with Zoom/Blur/Overlay or Soft Ambient Pastel Glow */}
      {activeBgSettings.imageUrl ? (
        <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
          <div
            className="absolute inset-0 transition-transform duration-300 origin-center"
            style={{
              backgroundImage: `url(${activeBgSettings.imageUrl})`,
              backgroundPosition: 'center',
              backgroundSize: 'cover',
              backgroundRepeat: 'no-repeat',
              transform: `scale(${activeBgSettings.zoom / 100})`,
              filter: `blur(${activeBgSettings.blur}px)`,
            }}
          />
          {/* Protective overlay to guarantee perfect contrast and legibility */}
          <div
            className="absolute inset-0 bg-white transition-opacity duration-200"
            style={{ opacity: activeBgSettings.overlayOpacity / 100 }}
          />
        </div>
      ) : (
        <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
          <div className="absolute -top-40 -left-40 w-96 h-96 bg-cyan-200/40 rounded-full blur-3xl" />
          <div className="absolute top-1/3 -right-40 w-96 h-96 bg-blue-200/30 rounded-full blur-3xl" />
          <div className="absolute -bottom-40 left-1/3 w-96 h-96 bg-emerald-200/30 rounded-full blur-3xl" />
        </div>
      )}

      {/* Minimalist Top Navigation Header */}
      <Navbar
        syncState={teamData.syncState}
        members={teamData.members}
        workspaceScope={workspaceScope}
        setWorkspaceScope={setWorkspaceScope}
        personalUser={personalUser}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onLogoutPersonal={handleLogoutPersonal}
        onOpenUpload={() => {
          setUploadTargetFolderId(undefined);
          setIsUploadOpen(true);
        }}
        onOpenNewFolder={() => setIsNewFolderOpen(true)}
        onOpenInfoHub={() => setIsInfoHubOpen(true)}
        onOpenTeam={() => setIsTeamDrawerOpen(true)}
        onOpenIE11Modal={() => setIsIE11ModalOpen(true)}
        onForceSync={fetchTeamWorkspace}
        isIE11Mode={isIE11Mode}
        activeMember={activeMember}
        onSelectMember={setActiveMember}
      />

      {/* Main Workspace Layout */}
      <main className="relative z-10 flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-5 space-y-4">
        {/* Minimalist Storage Overview, Search & Category Bar */}
        <StorageStatsBar
          files={currentFiles}
          folders={currentFolders}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          selectedCategory={selectedCategory}
          setSelectedCategory={setSelectedCategory}
          onNewFolder={() => setIsNewFolderOpen(true)}
          onDownloadAllAsZip={handleDownloadAllAsZip}
          usedBytes={currentUsedStorage}
          totalLimitBytes={currentLimitStorage}
          workspaceScope={workspaceScope}
          personalUser={personalUser}
        />

        {/* Crystalline Squircles Open Folders Grid */}
        <OpenFolderWorkspace
          folders={currentFolders}
          files={currentFiles}
          activeMember={activeMember}
          searchQuery={searchQuery}
          selectedCategory={selectedCategory}
          onPreviewFile={(file) => setSelectedFileForPreview(file)}
          onOpenVersions={(file) => setSelectedFileForVersions(file)}
          onToggleLock={handleToggleLock}
          onOpenComments={(file) => setSelectedFileForPreview(file)}
          onDeleteFile={handleDeleteFile}
          onUploadToFolder={(folderId) => {
            setUploadTargetFolderId(folderId);
            setIsUploadOpen(true);
          }}
          onDeleteFolder={handleDeleteFolder}
          onToggleFolderOpen={handleToggleFolderOpen}
          onDropFilesOnFolder={handleDropFilesOnFolder}
        />
      </main>

      {/* Personal Mode Authentication Modal (Google Sign-In or Email/Password) */}
      <PersonalAuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />

      {/* Upload Modal */}
      {isUploadOpen && (
        <UploadModal
          folders={currentFolders}
          files={currentFiles}
          initialFolderId={uploadTargetFolderId}
          onClose={() => setIsUploadOpen(false)}
          onUploadBatch={handleUploadBatch}
        />
      )}

      {/* Version History & Revert Modal */}
      {selectedFileForVersions && (
        <VersionHistoryModal
          file={selectedFileForVersions}
          onClose={() => setSelectedFileForVersions(null)}
          onRevertVersion={handleRevertVersion}
          onSaveNewRevision={handleSaveRevision}
        />
      )}

      {/* File Preview & Collaboration Modal */}
      {selectedFileForPreview && (
        <FilePreviewModal
          file={selectedFileForPreview}
          activeMember={activeMember}
          onClose={() => setSelectedFileForPreview(null)}
          onOpenVersions={(file) => {
            setSelectedFileForPreview(null);
            setSelectedFileForVersions(file);
          }}
          onToggleLock={handleToggleLock}
          onAddComment={handleAddComment}
          onSaveContentRevision={handleSaveRevision}
        />
      )}

      {/* New Folder Creation Modal */}
      {isNewFolderOpen && (
        <NewFolderModal
          isOpen={isNewFolderOpen}
          onClose={() => setIsNewFolderOpen(false)}
          onCreateFolder={handleCreateFolder}
        />
      )}

      {/* Team Collaboration Drawer */}
      <TeamCollaborationDrawer
        isOpen={isTeamDrawerOpen}
        onClose={() => setIsTeamDrawerOpen(false)}
        members={teamData.members}
        activities={teamData.activities}
        folders={teamData.folders}
        onAddMember={handleAddMember}
      />

      {/* IE11 Compatibility Inspector */}
      <IE11CompatibilityPanel
        isOpen={isIE11ModalOpen}
        onClose={() => setIsIE11ModalOpen(false)}
        isIE11Mode={isIE11Mode}
        setIsIE11Mode={setIsIE11Mode}
      />

      {/* Central Information Hub & Options FAB Modal */}
      <InfoHubModal
        isOpen={isInfoHubOpen}
        onClose={() => setIsInfoHubOpen(false)}
        workspaceScope={workspaceScope}
        setWorkspaceScope={setWorkspaceScope}
        personalUser={personalUser}
        onOpenAuthModal={() => {
          setIsInfoHubOpen(false);
          setIsAuthModalOpen(true);
        }}
        onLogoutPersonal={handleLogoutPersonal}
        teamData={teamData}
        personalFolders={personalFolders}
        personalFiles={personalFiles}
        personalStorageUsed={personalStorageUsed}
        personalStorageLimit={personalStorageLimit}
        activeMember={activeMember}
        onSelectMember={setActiveMember}
        onOpenTeam={() => {
          setIsInfoHubOpen(false);
          setIsTeamDrawerOpen(true);
        }}
        onOpenIE11Modal={() => {
          setIsInfoHubOpen(false);
          setIsIE11ModalOpen(true);
        }}
        onDownloadAllAsZip={handleDownloadAllAsZip}
        onClearSamples={handleClearSamples}
        onRestoreSamples={handleRestoreSamples}
        isIE11Mode={isIE11Mode}
        onForceSync={fetchTeamWorkspace}
        bgSettings={activeBgSettings}
        onUpdateBgSettings={handleUpdateBgSettings}
      />
    </div>
  );
}
